package com.example.spakowski.okrety;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.spakowski.okrety.Mechanizmy.Dodatkowe.Konwerter;
import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Plansza;
import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Statek;
import com.example.spakowski.okrety.Mechanizmy.Polaczenie.KlientBluetooth;
import com.example.spakowski.okrety.Mechanizmy.Polaczenie.SerwerBluetooth;
import com.example.spakowski.okrety.Mechanizmy.Tryby.PrzezBluetooth;

/**
 * Klasa aktywności rozgrywki przez bluetooth, zarządza ustanawianiem połączenia, umieszczeniem statków i samą grą
 */
public class GraBluetooth extends AppCompatActivity {
    //obiekty do obsługi interfejsu połączenia
    private Button serwer;
    private Button klient;
    private Button gotowy;
    private TextView status;
    private TextView funkcja;
    private TextView stan;
    private EditText adresMac;

    //obiekty do obsługi interfrjsu ustawiania statków
    private Button przelosuj;
    private Button dalej;
    private TextView gotowosc;
    private ImageView[][] Mapa; //potem wykorzystane do gry

    //obiekty do obsługi interfejsu rozgrywki
    private ImageView[] PrzyciskiX;
    private ImageView[] PrzyciskiY;
    private Button strzal;
    private TextView aktualny;

    //obiekty i zmienne obsługi rozgrywki
    private boolean typ;        //zmienna przechowuje typ(true - serwer, false - klient)
    private boolean ustawiony;  //flaga oznacza ze urządzenie ma ustawiony tryb
    private boolean blokuj;
    private boolean tura;       //true - gracz(ja), false - przeciwnik
    private KlientBluetooth gracz;
    private SerwerBluetooth host;
    private String w;               //zmienna do odczytywania/wysyłania wiadomości
    private Plansza plansza;        //plansza do gry, zależna od tego czy aktualny uzytkownik działa jako host czy gracz
    private Statek[] statki;        //statki pobrane od przeciwnika
    private PrzezBluetooth rozgrywka;
    private int x = 10, y = 10;
    private int xs, ys;//potrzebne do watku wykonującego ture przeciwnika

    /**
     * Metoda przypisuje elementy layoutu activity_gra_bluetooth do obiektów klasy
     */
    private void przypiszPolaczenie(){
        serwer = (Button) findViewById(R.id.serwer);
        klient = (Button) findViewById(R.id.klient);
        gotowy = (Button) findViewById(R.id.gotowy);
        status = (TextView) findViewById(R.id.mojAdres);
        funkcja = (TextView) findViewById(R.id.funkcja);
        stan = (TextView) findViewById(R.id.stan);
        adresMac = (EditText) findViewById(R.id.adres);
        ustawiony = false;
    }

    /**
     * Metoda przypisuje elementy layoutu bluetooth_ustaw_statki do obiektów klasy
     */
    private void przypiszUstaw(){
        Mapa = new ImageView[10][10];
        //pierwszy rząd
        this.Mapa[0][0] = (ImageView) findViewById(R.id.imageView221);
        this.Mapa[0][1] = (ImageView) findViewById(R.id.imageView222);
        this.Mapa[0][2] = (ImageView) findViewById(R.id.imageView223);
        this.Mapa[0][3] = (ImageView) findViewById(R.id.imageView224);
        this.Mapa[0][4] = (ImageView) findViewById(R.id.imageView225);
        this.Mapa[0][5] = (ImageView) findViewById(R.id.imageView226);
        this.Mapa[0][6] = (ImageView) findViewById(R.id.imageView227);
        this.Mapa[0][7] = (ImageView) findViewById(R.id.imageView228);
        this.Mapa[0][8] = (ImageView) findViewById(R.id.imageView229);
        this.Mapa[0][9] = (ImageView) findViewById(R.id.imageView230);
        //drugi rząd
        this.Mapa[1][0] = (ImageView) findViewById(R.id.imageView231);
        this.Mapa[1][1] = (ImageView) findViewById(R.id.imageView232);
        this.Mapa[1][2] = (ImageView) findViewById(R.id.imageView233);
        this.Mapa[1][3] = (ImageView) findViewById(R.id.imageView234);
        this.Mapa[1][4] = (ImageView) findViewById(R.id.imageView235);
        this.Mapa[1][5] = (ImageView) findViewById(R.id.imageView236);
        this.Mapa[1][6] = (ImageView) findViewById(R.id.imageView237);
        this.Mapa[1][7] = (ImageView) findViewById(R.id.imageView238);
        this.Mapa[1][8] = (ImageView) findViewById(R.id.imageView239);
        this.Mapa[1][9] = (ImageView) findViewById(R.id.imageView240);
        //trzeci rząd
        this.Mapa[2][0] = (ImageView) findViewById(R.id.imageView241);
        this.Mapa[2][1] = (ImageView) findViewById(R.id.imageView242);
        this.Mapa[2][2] = (ImageView) findViewById(R.id.imageView243);
        this.Mapa[2][3] = (ImageView) findViewById(R.id.imageView244);
        this.Mapa[2][4] = (ImageView) findViewById(R.id.imageView245);
        this.Mapa[2][5] = (ImageView) findViewById(R.id.imageView246);
        this.Mapa[2][6] = (ImageView) findViewById(R.id.imageView247);
        this.Mapa[2][7] = (ImageView) findViewById(R.id.imageView248);
        this.Mapa[2][8] = (ImageView) findViewById(R.id.imageView249);
        this.Mapa[2][9] = (ImageView) findViewById(R.id.imageView250);
        //czwarty rząd
        this.Mapa[3][0] = (ImageView) findViewById(R.id.imageView251);
        this.Mapa[3][1] = (ImageView) findViewById(R.id.imageView252);
        this.Mapa[3][2] = (ImageView) findViewById(R.id.imageView253);
        this.Mapa[3][3] = (ImageView) findViewById(R.id.imageView254);
        this.Mapa[3][4] = (ImageView) findViewById(R.id.imageView255);
        this.Mapa[3][5] = (ImageView) findViewById(R.id.imageView256);
        this.Mapa[3][6] = (ImageView) findViewById(R.id.imageView257);
        this.Mapa[3][7] = (ImageView) findViewById(R.id.imageView258);
        this.Mapa[3][8] = (ImageView) findViewById(R.id.imageView259);
        this.Mapa[3][9] = (ImageView) findViewById(R.id.imageView260);
        //piąty rząd
        this.Mapa[4][0] = (ImageView) findViewById(R.id.imageView261);
        this.Mapa[4][1] = (ImageView) findViewById(R.id.imageView262);
        this.Mapa[4][2] = (ImageView) findViewById(R.id.imageView263);
        this.Mapa[4][3] = (ImageView) findViewById(R.id.imageView264);
        this.Mapa[4][4] = (ImageView) findViewById(R.id.imageView265);
        this.Mapa[4][5] = (ImageView) findViewById(R.id.imageView266);
        this.Mapa[4][6] = (ImageView) findViewById(R.id.imageView267);
        this.Mapa[4][7] = (ImageView) findViewById(R.id.imageView268);
        this.Mapa[4][8] = (ImageView) findViewById(R.id.imageView269);
        this.Mapa[4][9] = (ImageView) findViewById(R.id.imageView270);
        //szósty rząd
        this.Mapa[5][0] = (ImageView) findViewById(R.id.imageView271);
        this.Mapa[5][1] = (ImageView) findViewById(R.id.imageView272);
        this.Mapa[5][2] = (ImageView) findViewById(R.id.imageView273);
        this.Mapa[5][3] = (ImageView) findViewById(R.id.imageView274);
        this.Mapa[5][4] = (ImageView) findViewById(R.id.imageView275);
        this.Mapa[5][5] = (ImageView) findViewById(R.id.imageView276);
        this.Mapa[5][6] = (ImageView) findViewById(R.id.imageView277);
        this.Mapa[5][7] = (ImageView) findViewById(R.id.imageView278);
        this.Mapa[5][8] = (ImageView) findViewById(R.id.imageView279);
        this.Mapa[5][9] = (ImageView) findViewById(R.id.imageView280);
        //siódmy rząd
        this.Mapa[6][0] = (ImageView) findViewById(R.id.imageView281);
        this.Mapa[6][1] = (ImageView) findViewById(R.id.imageView282);
        this.Mapa[6][2] = (ImageView) findViewById(R.id.imageView283);
        this.Mapa[6][3] = (ImageView) findViewById(R.id.imageView284);
        this.Mapa[6][4] = (ImageView) findViewById(R.id.imageView285);
        this.Mapa[6][5] = (ImageView) findViewById(R.id.imageView286);
        this.Mapa[6][6] = (ImageView) findViewById(R.id.imageView287);
        this.Mapa[6][7] = (ImageView) findViewById(R.id.imageView288);
        this.Mapa[6][8] = (ImageView) findViewById(R.id.imageView289);
        this.Mapa[6][9] = (ImageView) findViewById(R.id.imageView290);
        //ósmy rząd
        this.Mapa[7][0] = (ImageView) findViewById(R.id.imageView291);
        this.Mapa[7][1] = (ImageView) findViewById(R.id.imageView292);
        this.Mapa[7][2] = (ImageView) findViewById(R.id.imageView293);
        this.Mapa[7][3] = (ImageView) findViewById(R.id.imageView294);
        this.Mapa[7][4] = (ImageView) findViewById(R.id.imageView295);
        this.Mapa[7][5] = (ImageView) findViewById(R.id.imageView296);
        this.Mapa[7][6] = (ImageView) findViewById(R.id.imageView297);
        this.Mapa[7][7] = (ImageView) findViewById(R.id.imageView298);
        this.Mapa[7][8] = (ImageView) findViewById(R.id.imageView299);
        this.Mapa[7][9] = (ImageView) findViewById(R.id.imageView300);
        //dziewiąty rząd
        this.Mapa[8][0] = (ImageView) findViewById(R.id.imageView301);
        this.Mapa[8][1] = (ImageView) findViewById(R.id.imageView302);
        this.Mapa[8][2] = (ImageView) findViewById(R.id.imageView303);
        this.Mapa[8][3] = (ImageView) findViewById(R.id.imageView304);
        this.Mapa[8][4] = (ImageView) findViewById(R.id.imageView305);
        this.Mapa[8][5] = (ImageView) findViewById(R.id.imageView306);
        this.Mapa[8][6] = (ImageView) findViewById(R.id.imageView307);
        this.Mapa[8][7] = (ImageView) findViewById(R.id.imageView308);
        this.Mapa[8][8] = (ImageView) findViewById(R.id.imageView309);
        this.Mapa[8][9] = (ImageView) findViewById(R.id.imageView310);
        //dziesiąty rząd
        this.Mapa[9][0] = (ImageView) findViewById(R.id.imageView311);
        this.Mapa[9][1] = (ImageView) findViewById(R.id.imageView312);
        this.Mapa[9][2] = (ImageView) findViewById(R.id.imageView313);
        this.Mapa[9][3] = (ImageView) findViewById(R.id.imageView314);
        this.Mapa[9][4] = (ImageView) findViewById(R.id.imageView315);
        this.Mapa[9][5] = (ImageView) findViewById(R.id.imageView316);
        this.Mapa[9][6] = (ImageView) findViewById(R.id.imageView317);
        this.Mapa[9][7] = (ImageView) findViewById(R.id.imageView318);
        this.Mapa[9][8] = (ImageView) findViewById(R.id.imageView319);
        this.Mapa[9][9] = (ImageView) findViewById(R.id.imageView320);

        this.przelosuj = (Button) findViewById(R.id.przelosuj);
        this.dalej = (Button) findViewById(R.id.dalej);
        this.gotowosc = (TextView) findViewById(R.id.gotowosc);
    }

    /**
     * Metoda przypisuje elementy layoutu android_gra do obiektów klasy,
     * zakłada że Mapa jest już zainicjowana
     */
    private void przypiszGra(){
        //pierwszy rząd
        this.Mapa[0][0] = (ImageView) findViewById(R.id.imageView101);
        this.Mapa[0][1] = (ImageView) findViewById(R.id.imageView102);
        this.Mapa[0][2] = (ImageView) findViewById(R.id.imageView103);
        this.Mapa[0][3] = (ImageView) findViewById(R.id.imageView104);
        this.Mapa[0][4] = (ImageView) findViewById(R.id.imageView105);
        this.Mapa[0][5] = (ImageView) findViewById(R.id.imageView106);
        this.Mapa[0][6] = (ImageView) findViewById(R.id.imageView107);
        this.Mapa[0][7] = (ImageView) findViewById(R.id.imageView108);
        this.Mapa[0][8] = (ImageView) findViewById(R.id.imageView109);
        this.Mapa[0][9] = (ImageView) findViewById(R.id.imageView110);
        //drugi rząd
        this.Mapa[1][0] = (ImageView) findViewById(R.id.imageView111);
        this.Mapa[1][1] = (ImageView) findViewById(R.id.imageView112);
        this.Mapa[1][2] = (ImageView) findViewById(R.id.imageView113);
        this.Mapa[1][3] = (ImageView) findViewById(R.id.imageView114);
        this.Mapa[1][4] = (ImageView) findViewById(R.id.imageView115);
        this.Mapa[1][5] = (ImageView) findViewById(R.id.imageView116);
        this.Mapa[1][6] = (ImageView) findViewById(R.id.imageView117);
        this.Mapa[1][7] = (ImageView) findViewById(R.id.imageView118);
        this.Mapa[1][8] = (ImageView) findViewById(R.id.imageView119);
        this.Mapa[1][9] = (ImageView) findViewById(R.id.imageView120);
        //trzeci rząd
        this.Mapa[2][0] = (ImageView) findViewById(R.id.imageView121);
        this.Mapa[2][1] = (ImageView) findViewById(R.id.imageView122);
        this.Mapa[2][2] = (ImageView) findViewById(R.id.imageView123);
        this.Mapa[2][3] = (ImageView) findViewById(R.id.imageView124);
        this.Mapa[2][4] = (ImageView) findViewById(R.id.imageView125);
        this.Mapa[2][5] = (ImageView) findViewById(R.id.imageView126);
        this.Mapa[2][6] = (ImageView) findViewById(R.id.imageView127);
        this.Mapa[2][7] = (ImageView) findViewById(R.id.imageView128);
        this.Mapa[2][8] = (ImageView) findViewById(R.id.imageView129);
        this.Mapa[2][9] = (ImageView) findViewById(R.id.imageView130);
        //czwarty rząd
        this.Mapa[3][0] = (ImageView) findViewById(R.id.imageView131);
        this.Mapa[3][1] = (ImageView) findViewById(R.id.imageView132);
        this.Mapa[3][2] = (ImageView) findViewById(R.id.imageView133);
        this.Mapa[3][3] = (ImageView) findViewById(R.id.imageView134);
        this.Mapa[3][4] = (ImageView) findViewById(R.id.imageView135);
        this.Mapa[3][5] = (ImageView) findViewById(R.id.imageView136);
        this.Mapa[3][6] = (ImageView) findViewById(R.id.imageView137);
        this.Mapa[3][7] = (ImageView) findViewById(R.id.imageView138);
        this.Mapa[3][8] = (ImageView) findViewById(R.id.imageView139);
        this.Mapa[3][9] = (ImageView) findViewById(R.id.imageView140);
        //piąty rząd
        this.Mapa[4][0] = (ImageView) findViewById(R.id.imageView141);
        this.Mapa[4][1] = (ImageView) findViewById(R.id.imageView142);
        this.Mapa[4][2] = (ImageView) findViewById(R.id.imageView143);
        this.Mapa[4][3] = (ImageView) findViewById(R.id.imageView144);
        this.Mapa[4][4] = (ImageView) findViewById(R.id.imageView145);
        this.Mapa[4][5] = (ImageView) findViewById(R.id.imageView146);
        this.Mapa[4][6] = (ImageView) findViewById(R.id.imageView147);
        this.Mapa[4][7] = (ImageView) findViewById(R.id.imageView148);
        this.Mapa[4][8] = (ImageView) findViewById(R.id.imageView149);
        this.Mapa[4][9] = (ImageView) findViewById(R.id.imageView150);
        //szósty rząd
        this.Mapa[5][0] = (ImageView) findViewById(R.id.imageView151);
        this.Mapa[5][1] = (ImageView) findViewById(R.id.imageView152);
        this.Mapa[5][2] = (ImageView) findViewById(R.id.imageView153);
        this.Mapa[5][3] = (ImageView) findViewById(R.id.imageView154);
        this.Mapa[5][4] = (ImageView) findViewById(R.id.imageView155);
        this.Mapa[5][5] = (ImageView) findViewById(R.id.imageView156);
        this.Mapa[5][6] = (ImageView) findViewById(R.id.imageView157);
        this.Mapa[5][7] = (ImageView) findViewById(R.id.imageView158);
        this.Mapa[5][8] = (ImageView) findViewById(R.id.imageView159);
        this.Mapa[5][9] = (ImageView) findViewById(R.id.imageView160);
        //siódmy rząd
        this.Mapa[6][0] = (ImageView) findViewById(R.id.imageView161);
        this.Mapa[6][1] = (ImageView) findViewById(R.id.imageView162);
        this.Mapa[6][2] = (ImageView) findViewById(R.id.imageView163);
        this.Mapa[6][3] = (ImageView) findViewById(R.id.imageView164);
        this.Mapa[6][4] = (ImageView) findViewById(R.id.imageView165);
        this.Mapa[6][5] = (ImageView) findViewById(R.id.imageView166);
        this.Mapa[6][6] = (ImageView) findViewById(R.id.imageView167);
        this.Mapa[6][7] = (ImageView) findViewById(R.id.imageView168);
        this.Mapa[6][8] = (ImageView) findViewById(R.id.imageView169);
        this.Mapa[6][9] = (ImageView) findViewById(R.id.imageView170);
        //ósmy rząd
        this.Mapa[7][0] = (ImageView) findViewById(R.id.imageView171);
        this.Mapa[7][1] = (ImageView) findViewById(R.id.imageView172);
        this.Mapa[7][2] = (ImageView) findViewById(R.id.imageView173);
        this.Mapa[7][3] = (ImageView) findViewById(R.id.imageView174);
        this.Mapa[7][4] = (ImageView) findViewById(R.id.imageView175);
        this.Mapa[7][5] = (ImageView) findViewById(R.id.imageView176);
        this.Mapa[7][6] = (ImageView) findViewById(R.id.imageView177);
        this.Mapa[7][7] = (ImageView) findViewById(R.id.imageView178);
        this.Mapa[7][8] = (ImageView) findViewById(R.id.imageView179);
        this.Mapa[7][9] = (ImageView) findViewById(R.id.imageView180);
        //dziewiąty rząd
        this.Mapa[8][0] = (ImageView) findViewById(R.id.imageView181);
        this.Mapa[8][1] = (ImageView) findViewById(R.id.imageView182);
        this.Mapa[8][2] = (ImageView) findViewById(R.id.imageView183);
        this.Mapa[8][3] = (ImageView) findViewById(R.id.imageView184);
        this.Mapa[8][4] = (ImageView) findViewById(R.id.imageView185);
        this.Mapa[8][5] = (ImageView) findViewById(R.id.imageView186);
        this.Mapa[8][6] = (ImageView) findViewById(R.id.imageView187);
        this.Mapa[8][7] = (ImageView) findViewById(R.id.imageView188);
        this.Mapa[8][8] = (ImageView) findViewById(R.id.imageView189);
        this.Mapa[8][9] = (ImageView) findViewById(R.id.imageView190);
        //dziesiąty rząd
        this.Mapa[9][0] = (ImageView) findViewById(R.id.imageView191);
        this.Mapa[9][1] = (ImageView) findViewById(R.id.imageView192);
        this.Mapa[9][2] = (ImageView) findViewById(R.id.imageView193);
        this.Mapa[9][3] = (ImageView) findViewById(R.id.imageView194);
        this.Mapa[9][4] = (ImageView) findViewById(R.id.imageView195);
        this.Mapa[9][5] = (ImageView) findViewById(R.id.imageView196);
        this.Mapa[9][6] = (ImageView) findViewById(R.id.imageView197);
        this.Mapa[9][7] = (ImageView) findViewById(R.id.imageView198);
        this.Mapa[9][8] = (ImageView) findViewById(R.id.imageView199);
        this.Mapa[9][9] = (ImageView) findViewById(R.id.imageView200);

        PrzyciskiX = new ImageView[10];
        PrzyciskiY = new ImageView[10];
        //przypisanie do przycisków po boku
        PrzyciskiY[0] = (ImageView) findViewById(R.id.imageView201);
        PrzyciskiY[1] = (ImageView) findViewById(R.id.imageView202);
        PrzyciskiY[2] = (ImageView) findViewById(R.id.imageView203);
        PrzyciskiY[3] = (ImageView) findViewById(R.id.imageView204);
        PrzyciskiY[4] = (ImageView) findViewById(R.id.imageView205);
        PrzyciskiY[5] = (ImageView) findViewById(R.id.imageView206);
        PrzyciskiY[6] = (ImageView) findViewById(R.id.imageView207);
        PrzyciskiY[7] = (ImageView) findViewById(R.id.imageView208);
        PrzyciskiY[8] = (ImageView) findViewById(R.id.imageView209);
        PrzyciskiY[9] = (ImageView) findViewById(R.id.imageView210);
        //przyciski pod mapą
        PrzyciskiX[0] = (ImageView) findViewById(R.id.imageView211);
        PrzyciskiX[1] = (ImageView) findViewById(R.id.imageView212);
        PrzyciskiX[2] = (ImageView) findViewById(R.id.imageView213);
        PrzyciskiX[3] = (ImageView) findViewById(R.id.imageView214);
        PrzyciskiX[4] = (ImageView) findViewById(R.id.imageView215);
        PrzyciskiX[5] = (ImageView) findViewById(R.id.imageView216);
        PrzyciskiX[6] = (ImageView) findViewById(R.id.imageView217);
        PrzyciskiX[7] = (ImageView) findViewById(R.id.imageView218);
        PrzyciskiX[8] = (ImageView) findViewById(R.id.imageView219);
        PrzyciskiX[9] = (ImageView) findViewById(R.id.imageView220);

        strzal = (Button) findViewById(R.id.strzal);
        aktualny = (TextView) findViewById(R.id.aktualnygracz);
    }

    /**
     * Metoda zastępuje obrazki na mapie na woda.png(restartuje mapę)
     */
    private void resetMapy(){
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                this.Mapa[i][j].setImageResource(R.drawable.woda);
            }
        }
    }

    /**
     * Metoda nanosi na mapę podaną Mapkę, bez nakładki
     *
     * @param Mapka tablica dwuwymiarowa Mapa pobierana z obiektu PrzezBluetooth, VsAndroid lub Plansza
     */
    private void rysujMape(int[][] Mapka){
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                int kod = Mapka[i][j];
                switch (kod){
                    case 0:
                        this.Mapa[i][j].setImageResource(R.drawable.woda);
                        break;
                    case 1:
                        this.Mapa[i][j].setImageResource(R.drawable.wodapudlo);
                        break;
                    case 2:
                        this.Mapa[i][j].setImageResource(R.drawable.statektrafiony);
                        break;
                }
            }
        }
    }

    /**
     * Metoda nanosi na mapę podaną Mapkę z nakładką
     *
     * @param Mapka tablica dwuwymiarowa Mapa pobierana z obiektu PrzezBluetooth, VsAndroid lub Plansza
     * @param Nakladka tablica dwuwymiarowa Wzór pobierana z obiektu PrzezBluetooth, VsAndroid lub Plansza
     */
    private void rysujMape(int[][] Mapka, boolean[][] Nakladka){
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                int kod = Mapka[i][j];
                switch (kod){
                    case 0:
                        if(Nakladka[i][j] == true){
                            this.Mapa[i][j].setImageResource(R.drawable.statek);
                        }
                        else {
                            this.Mapa[i][j].setImageResource(R.drawable.woda);
                        }
                        break;
                    case 1:
                        this.Mapa[i][j].setImageResource(R.drawable.wodapudlo);
                        break;
                    case 2:
                        this.Mapa[i][j].setImageResource(R.drawable.statektrafiony);
                        break;
                }
            }
        }
    }

    /**
     * Metoda resetuje mapę(ustawia obrazki na woda.png) i umieszcza statki(zastępuje odpowiednie pola na statek.png)
     */
    private void odswierzMapeUstaw(){
        Statek[] Statki = plansza.getStatki();
        int[][] pozycje;

        resetMapy();

        for(int i = 0; i < 10; i++){//for przechodzi po każdym statku
            pozycje = Statki[i].getPozycje();
            for(int j = 0; j < Statki[i].getDlugosc(); j++) {//for przechodzi po wszystkich fragmentach statku
                Mapa[pozycje[j][1]][pozycje[j][0]].setImageResource(R.drawable.statek);
            }
        }
    }

    /**
     * Metoda odczytuje wiadomość wysłaną przez serwer/klienta
     * @return Zwraca treść wiadomości
     */
    private String odczyt(){
        String w;
        if(typ == true){
            w = host.odbierz();
        }
        else {
            w = gracz.odbierz();
        }
        return w;
    }

    /**
     * Metoda wysyła podaną wiadomość do klienta/serwera
     * @param wiadomosc wiadomość do wysłania
     */
    private void wyslanie(String wiadomosc){
        if(typ == true){
            host.wyslij(wiadomosc);
        }
        else {
            gracz.wyslij(wiadomosc);
        }
    }

    /**
     * Metoda zmienia obrazek na mapie,
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     * @param typ Określa jaki będzie obrazek:
     *            1 - woda
     *            2 - statek
     * @param wersja Określa rodzaj obrazka:
     *               1 - normalny
     *               2 - celuje
     *               3 - pudlo/zatopiony
     * @return Zwraca:
     * 0 - bez błedu
     * 1 - błąd, złe współrzędne
     * 2 - błąd, zły typ
     * 3 - błąd, zła wersja
     */
    private int zmienObrazek(int x, int y, int typ, int wersja){
        int kod = 0;
        if((x>9) || (x<0) || (y<0) || (y>9)){
            kod = 1;
        }
        else {
            switch (typ) {//wybór typu
                case 1://woda
                    switch(wersja){
                        case 1:
                            Mapa[y][x].setImageResource(R.drawable.woda);
                            break;
                        case 2:
                            Mapa[y][x].setImageResource(R.drawable.wodaceluje);
                            break;
                        case 3:
                            Mapa[y][x].setImageResource(R.drawable.wodapudlo);
                            break;
                        default:
                            kod = 3;
                            break;
                    }
                    break;
                case 2://statek pion
                    switch(wersja){
                        case 1:
                            Mapa[y][x].setImageResource(R.drawable.statek);
                            break;
                        case 2:
                            Mapa[y][x].setImageResource(R.drawable.statekceluje);
                            break;
                        case 3:
                            Mapa[y][x].setImageResource(R.drawable.statektrafiony);
                            break;
                        default:
                            kod = 3;
                            break;
                    }
                    break;
                default://jak zła wartość
                    kod = 2;
                    break;
            }
        }
        return kod;
    }

    /**
     * Wewnętrzna klasa działa jako wątek oczekujący na gotowość drugiego gracza
     */
    private class WatekGotowosc implements Runnable{
        boolean zakoncz = false;
        @Override
        public void run(){
            while (zakoncz == false){
                w = odczyt();
                if(w.equals("koniec")){
                    zakoncz = true;
                    wyswietlOkno("Błąd połączenia, rozłączono.");
                }
                else {
                    if(w.equals("gotowy")){
                        zakoncz = true;
                        int kod = 0;
                        przeslijStatki(plansza);
                        kod = odbierzStatki();
                        switch (kod){
                            case 0:
                                tworzGre();
                                break;
                            case -1:
                                runOnUiThread(new Runnable(){
                                    @Override
                                    public void run(){
                                        wyswietlOkno("Błąd połączenia, rozłączono.");
                                    }
                                });
                                break;
                            case -2:
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        wyswietlOkno("Błąd połączenia, spróbuj ponownie.");
                                    }
                                });
                                break;
                        }
                    }
                }
            }
        }
    }

    /**
     * Obiekt wątku odpowiadający za turę przeciwnika
     * odbiera wiadomości od przeciwnika i oznacza mapę u aktualnego gracza
     * wywoływany jak gracz skończy turę, kończy się gdy przeciwnik skończy turę
     */
    private class WatekStrzaly implements Runnable{
        boolean zakoncz = false;
        int kod;
        @Override
        public void run(){
            while(zakoncz == false){
                w = odczyt();
                if(w.equals("twoja")){
                    tura = true;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            aktualny.setText("Ty");
                            rysujMape(rozgrywka.getPrzeciwnikMapa());
                        }
                    });
                    blokuj = false;
                    zakoncz = true;
                }
                else {
                    if(w.equals("koniec")){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                wyswietlOkno("Błąd połączenia, rozłączono");
                            }
                        });
                        zakoncz = true;
                    }
                    else {
                        xs = Character.getNumericValue(w.charAt(0));
                        ys = Character.getNumericValue(w.charAt(1));
                        kod = rozgrywka.strzalPrzeciwnik(xs, ys);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Handler handle = new Handler();
                                switch (kod){
                                    case 1:
                                        zmienObrazek(xs, ys, 1, 2);
                                        handle.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                zmienObrazek(xs, ys, 1, 3);

                                            }
                                        }, 1000);
                                        break;
                                    case 2:
                                        zmienObrazek(xs, ys, 2, 2);
                                        handle.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                zmienObrazek(xs, ys, 2, 3);
                                            }
                                        }, 1000);
                                        break;
                                    case 3:
                                        zmienObrazek(xs, ys, 2, 2);
                                        handle.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                rysujMape(rozgrywka.getGraczMapa(), rozgrywka.getGraczWzor());
                                            }
                                        }, 1000);
                                        handle.postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                if(rozgrywka.koniecPrzeciwnik() == true){
                                                    wyswietlOkno("Przegrana");
                                                }
                                            }
                                        }, 2000);
                                        break;
                                }
                            }
                        });

                    }
                }
            }
        }
    }

    /**
     * Metoda zamienia statki na paczki i wysyła je do hosta
     *
     * @param mapka obiekt typu Plansza zawierający statki które mają zostać wysłane
     */
    private void przeslijStatki(Plansza mapka){
        Statek[] statki = mapka.getStatki();
        Konwerter konw = new Konwerter();
        String[] paczki;
        paczki = konw.StatkiNaPaczki(statki);
        wyslanie("statki");
        for (int i = 0; i < 10; i++) {
            wyslanie(paczki[i]);
        }
        wyslanie("wszystkie");
    }

    /**
     * Metoda odbiera przesłane statki i je odtwarza
     * @return Zwraca:
     * 0 gdy się powiodło
     * -1 gdy przerwano połączenie
     * -2 gdy wystapił błąd komunikacji(nie poprawna wiadomość, zła kolejność)
     */
    private int odbierzStatki(){
        int kod = 0;
        Konwerter konw = new Konwerter();
        String[] paczki = new String[10];
        String w;
        w = odczyt();
        if(w.equals("statki")){
            //odbieranie paczek
            for(int i = 0; i < 10; i++){
                paczki[i] = odczyt();
                if(paczki[i].equals("koniec")){
                    kod = -1;
                    i = 10;
                }
                else {
                    if(paczki[i].equals("wszystkie")){
                        kod = -2;
                    }
                }
            }
            w = odczyt();
            if(w.equals("koniec")){
                kod = -1;
            }
            else {
                statki = konw.PaczkiNaStatki(paczki);
            }
        }
        else {
            if(w.equals("koniec")){
                kod = -1;
            }
            else {
                kod = -2;
            }
        }
        return kod;
    }

    /**
     * Metoda tworzy obiekt rozgrywki z statków odebranych i wczesniej ustawionych
     * oraz zamienia layout na wersje do gry, gdy jest wywołana u klienta uruchamia wątek wykonujący turę przeciwnika
     */
    private void tworzGre(){
        Plansza przeciwnik = new Plansza(statki);
        rozgrywka = new PrzezBluetooth(przeciwnik, plansza);

        //zmiana layoutu
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                setContentView(R.layout.android_gra);
                przypiszGra();
                nadpiszNalsuchyGra();

                //tura, zmienna blokuj wyznacza turę(z pomoca komunikatów przesyłanych między urządzeniami)
                if(typ == true){
                    blokuj = false;
                    tura = true;
                    aktualny.setText("Ty");
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            rysujMape(rozgrywka.getPrzeciwnikMapa());
                        }
                    });
                }
                else {
                    blokuj = true;
                    tura = false;
                    aktualny.setText("Przeciwnik");
                    rysujMape(rozgrywka.getGraczMapa(), rozgrywka.getGraczWzor());
                    //watek przeciwnika
                    WatekStrzaly watek = new WatekStrzaly();
                    Thread thread = new Thread(watek);
                    thread.start();
                }
            }
        });

    }

    /**
     * Metoda ustawia obrazki dla PrzyciskiX(przyciski pod mapą podczas rozgrywce) na domyślne
     */
    private void resetwyboruX(){
        PrzyciskiX[0].setImageResource(R.drawable.zero);
        PrzyciskiX[1].setImageResource(R.drawable.jeden);
        PrzyciskiX[2].setImageResource(R.drawable.dwa);
        PrzyciskiX[3].setImageResource(R.drawable.trzy);
        PrzyciskiX[4].setImageResource(R.drawable.cztery);
        PrzyciskiX[5].setImageResource(R.drawable.piec);
        PrzyciskiX[6].setImageResource(R.drawable.szesc);
        PrzyciskiX[7].setImageResource(R.drawable.siedem);
        PrzyciskiX[8].setImageResource(R.drawable.osiem);
        PrzyciskiX[9].setImageResource(R.drawable.dziewiec);
    }

    /**
     * Metoda ustawia obrazki dla PrzyciskiY(przyciski obok mapy podczas rozgrywki) na domyślne
     */
    private void resetwyboruY(){
        PrzyciskiY[0].setImageResource(R.drawable.zero);
        PrzyciskiY[1].setImageResource(R.drawable.jeden);
        PrzyciskiY[2].setImageResource(R.drawable.dwa);
        PrzyciskiY[3].setImageResource(R.drawable.trzy);
        PrzyciskiY[4].setImageResource(R.drawable.cztery);
        PrzyciskiY[5].setImageResource(R.drawable.piec);
        PrzyciskiY[6].setImageResource(R.drawable.szesc);
        PrzyciskiY[7].setImageResource(R.drawable.siedem);
        PrzyciskiY[8].setImageResource(R.drawable.osiem);
        PrzyciskiY[9].setImageResource(R.drawable.dziewiec);
    }

    /**
     * Metoda wyswietla okno z podanym tekstem i zamyka akrywność
     *
     * @param wiadomosc text wyświetlany w oknie
     */
    private void wyswietlOkno(String wiadomosc){
        final AlertDialog Okienko = new AlertDialog.Builder(GraBluetooth.this).create();
        Okienko.setTitle(wiadomosc);
        Okienko.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(typ== true){
                    host.wyslij("koniec");
                }
                else {
                    gracz.wyslij("koniec");
                }
                dialog.dismiss();
                GraBluetooth.this.finish();
            }
        });
        Okienko.show();
    }

    /**
     * Metoda nadpisuje nasłuchy(Listenery) w layoucie ustawiania statków
     */
    private void nadpiszNalsuchyUstaw(){
        this.przelosuj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false){
                    plansza.wypelnij();
                    odswierzMapeUstaw();
                }
            }
        });

        this.dalej.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    blokuj = true;
                    gotowosc.setText("Gotowy");
                    wyslanie("gotowy");
                    WatekGotowosc watek = new WatekGotowosc();//watek czekający na drugiego i ustawiający gre
                    Thread thread = new Thread(watek);
                    thread.start();
                }
            }
        });
    }

    /**
     * Metoda nadpisuje nasłuchy(Listenery) w layoucie rozgrywki
     */
    private void nadpiszNalsuchyGra(){
        //przyciski pod mapą
        //przycisk 0
        PrzyciskiX[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 0;
                    PrzyciskiX[0].setImageResource(R.drawable.zerowybrane);
                }
            }
        });
        //przycisk 1
        PrzyciskiX[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 1;
                    PrzyciskiX[1].setImageResource(R.drawable.jedenwybrane);
                }
            }
        });
        //przycisk 2
        PrzyciskiX[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 2;
                    PrzyciskiX[2].setImageResource(R.drawable.dwawybrane);
                }
            }
        });
        //przycisk 3
        PrzyciskiX[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 3;
                    PrzyciskiX[3].setImageResource(R.drawable.trzywybrane);
                }
            }
        });
        //przycisk 4
        PrzyciskiX[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 4;
                    PrzyciskiX[4].setImageResource(R.drawable.czterywybrane);
                }
            }
        });
        //przycisk 5
        PrzyciskiX[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 5;
                    PrzyciskiX[5].setImageResource(R.drawable.piecwybrane);
                }
            }
        });
        //przycisk 6
        PrzyciskiX[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 6;
                    PrzyciskiX[6].setImageResource(R.drawable.szescwybrane);
                }
            }
        });
        //przycisk 7
        PrzyciskiX[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 7;
                    PrzyciskiX[7].setImageResource(R.drawable.siedemwybrane);
                }
            }
        });
        //przycisk 8
        PrzyciskiX[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 8;
                    PrzyciskiX[8].setImageResource(R.drawable.osiemwybrane);
                }
            }
        });
        //przycisk 9
        PrzyciskiX[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 9;
                    PrzyciskiX[9].setImageResource(R.drawable.dziewiecwybrane);
                }
            }
        });

        //przyciski obok mapy
        //przycisk 0
        PrzyciskiY[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 0;
                    PrzyciskiY[0].setImageResource(R.drawable.zerowybrane);
                }
            }
        });
        //przycisk 1
        PrzyciskiY[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 1;
                    PrzyciskiY[1].setImageResource(R.drawable.jedenwybrane);
                }
            }
        });
        //przycisk 2
        PrzyciskiY[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 2;
                    PrzyciskiY[2].setImageResource(R.drawable.dwawybrane);
                }
            }
        });
        //przycisk 3
        PrzyciskiY[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 3;
                    PrzyciskiY[3].setImageResource(R.drawable.trzywybrane);
                }
            }
        });
        //przycisk 4
        PrzyciskiY[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 4;
                    PrzyciskiY[4].setImageResource(R.drawable.czterywybrane);
                }
            }
        });
        //przycisk 5
        PrzyciskiY[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 5;
                    PrzyciskiY[5].setImageResource(R.drawable.piecwybrane);
                }
            }
        });
        //przycisk 6
        PrzyciskiY[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 6;
                    PrzyciskiY[6].setImageResource(R.drawable.szescwybrane);
                }
            }
        });
        //przycisk 7
        PrzyciskiY[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 7;
                    PrzyciskiY[7].setImageResource(R.drawable.siedemwybrane);
                }
            }
        });
        //przycisk 8
        PrzyciskiY[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 8;
                    PrzyciskiY[8].setImageResource(R.drawable.osiemwybrane);
                }
            }
        });
        //przycisk 9
        PrzyciskiY[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 9;
                    PrzyciskiY[9].setImageResource(R.drawable.dziewiecwybrane);
                }
            }
        });

        this.strzal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false){
                    blokuj = true;
                    int kod = rozgrywka.strzalGracz(x, y);
                    if(kod != -1) {
                        w = String.valueOf(x) + String.valueOf(y);
                        wyslanie(w);
                        Handler handle = new Handler();
                        switch (kod) {
                            case 1:
                                zmienObrazek(x, y, 1, 2);
                                handle.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        zmienObrazek(x, y, 1, 3);

                                    }
                                }, 1000);
                                handle.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        rysujMape(rozgrywka.getGraczMapa());
                                        aktualny.setText("Przeciwnik");
                                        //watek przeciwnika
                                        tura = false;
                                        wyslanie("twoja");
                                        WatekStrzaly watek = new WatekStrzaly();
                                        Thread thread = new Thread(watek);
                                        thread.start();
                                    }
                                }, 2000);
                                break;
                            case 2:
                                zmienObrazek(x, y, 1, 2);
                                handle.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        zmienObrazek(x, y, 2, 3);
                                        blokuj = false;
                                    }
                                }, 1000);
                                break;
                            case 3:
                                zmienObrazek(x, y, 2, 2);
                                handle.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        rysujMape(rozgrywka.getPrzeciwnikMapa());
                                    }
                                }, 1000);
                                handle.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        if(rozgrywka.koniecGracz()){
                                            wyswietlOkno("Wygrana!");
                                        }
                                        blokuj = false;
                                    }
                                }, 2000);
                                break;
                        }
                    }
                    else {
                        blokuj = false;
                    }
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gra_bluetooth);
        blokuj = false;
        przypiszPolaczenie();

        //nasłuch na przycisku gotowości
        gotowy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (blokuj == false && ustawiony == true) {
                    if(typ == true) {
                        if (host.aktualnyStan() == true) {
                            String w = host.odbierz();
                            if (w.equals("gotowy")) {
                                setContentView(R.layout.bluetooth_ustaw_statki);
                                przypiszUstaw();
                                nadpiszNalsuchyUstaw();
                                plansza = new Plansza();
                                blokuj = false;
                            } else {
                                if (w.equals("koniec")) {
                                    wyswietlOkno("Przerwano połączenie");
                                }
                            }
                        } else {
                            stan.setText("Serwer nie gotowy.");
                        }
                    }
                    else {
                        if(gracz.aktualnyStan() == true){
                            gracz.wyslij("gotowy");
                            setContentView(R.layout.bluetooth_ustaw_statki);
                            przypiszUstaw();
                            nadpiszNalsuchyUstaw();
                            plansza = new Plansza();
                            blokuj = false;
                        }
                        else {
                            stan.setText("Wcisnij ponownie.");
                        }
                    }
                }
            }
        });

        //nasłuch na przycisku ustawiania serwera, blokuje przyciski na 10 sec, czas oczekiwania na serwer
        serwer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    blokuj = true;
                    funkcja.setText("Funkcja: Host");
                    typ = true;
                    host = new SerwerBluetooth();
                    host.start();
                    ustawiony = true;
                    Handler hand = new Handler();
                    hand.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if(host.aktualnyStan() == false){
                                funkcja.setText("Przekroczono czas oczekiwania. Spróbuj ponownie.");
                            }
                            else {
                                funkcja.setText("Funkcja: Host, połączono");
                            }
                            blokuj = false;
                        }
                    }, 10000);
                }
            }
        });

        //nadpisanie nasłuchu na przyciski klienta(gracza), wykonanie próby połączenia z podanym adresem
        klient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (blokuj == false) {
                    funkcja.setText("Funkcja: Gracz");
                    try {
                        typ = false;
                        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
                        BluetoothDevice serw = ba.getRemoteDevice(adresMac.getText().toString());
                        gracz = new KlientBluetooth(serw);
                        gracz.start();
                        ustawiony = true;
                    } catch (Exception e) {
                        funkcja.setText("Bledny adres.");
                        ustawiony = false;
                    }
                }
            }
        });

        BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        status.setText("Mój adres:  "+ ba.getAddress());
        if(!ba.isEnabled()){
            Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(intent, 1);
        }
    }

    @Override
    protected void onActivityResult(int reqiestCode, int resultCode, Intent i){
        if(resultCode == Activity.RESULT_OK){
            BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
        }
    }

    @Override
    public void onBackPressed(){
        if(ustawiony == true) {
            if (typ == false) {
                if(gracz.aktualnyStan() == true){
                    gracz.wyslij("koniec");
                }
            } else {
                if(host.aktualnyStan() == true){
                    host.wyslij("koniec");
                }
            }
        }
        super.onBackPressed();
    }
}
