package com.example.spakowski.okrety;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Klasa aktywności wyświetlającej informacje o grze
 */
public class Informacje extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_informacje);
    }
}
