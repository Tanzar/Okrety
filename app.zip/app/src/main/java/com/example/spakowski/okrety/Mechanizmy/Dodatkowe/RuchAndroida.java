package com.example.spakowski.okrety.Mechanizmy.Dodatkowe;

/**
 * Created by SPAKOWSKI on 2016-11-19.
 */

/**
 * Klasa reprezentująca jeden ruch androida, przechowuje informację:
 * -współrzędne X i Y strzału
 * -flagę trafienia
 * -kod uzyskany po trafieniu
 */
public class RuchAndroida {
    private int x;
    private int y;
    private boolean trafiony;
    private int kod;

    public RuchAndroida(){
    }

    public RuchAndroida(int x, int y, boolean trafiony){
        this.x = x;
        this.y = y;
        this.trafiony = trafiony;
    }

    public RuchAndroida(int x, int y, boolean trafiony, int kod){
        this.x = x;
        this.y = y;
        this.trafiony = trafiony;
        this.kod = kod;
    }

    public void setX(int x){
        this.x = x;
    }

    public void setY(int y){
        this.y = y;
    }

    public void setTrafiony(boolean trafiony){
        this.trafiony = trafiony;
    }

    public void setKod(int kod){
        this.kod = kod;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public boolean getTrafiony(){
        return this.trafiony;
    }

    public int getKod(){
        return this.kod;
    }
}
