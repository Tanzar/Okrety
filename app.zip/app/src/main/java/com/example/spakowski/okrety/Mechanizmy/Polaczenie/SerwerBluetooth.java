package com.example.spakowski.okrety.Mechanizmy.Polaczenie;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;

import com.example.spakowski.okrety.Mechanizmy.Tryby.PrzezBluetooth;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.UUID;

/**
 * Created by SPAKOWSKI on 2016-11-22.
 */

/**
 * Klasa serwera odpowiedzialna za połączenie z klientem i komunikację
 */
public class SerwerBluetooth extends Thread {
    private final BluetoothServerSocket mmServerSocket;
    private PrintWriter out;
    private BufferedReader in;
    private boolean status = false; //stan serwera(false - nieaktywny, true - aktywny)
    private BluetoothSocket socket = null;

    /**
     * Konstruktor przygotowuje serwer do próby podjęcia połączenia
     */
    public SerwerBluetooth() {
        BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        BluetoothServerSocket tmp = null;
        try{
            UUID uuid = UUID.fromString("b791d4c7-c29d-4cb9-aa3a-233ae216e593");
            tmp = mBluetoothAdapter.listenUsingRfcommWithServiceRecord("Gra Statki", uuid);
        }
        catch (IOException e){
        }
        this.mmServerSocket = tmp;
    }

    /**
     * Jednorazowe nasłuchiwanie przez 10 sekund na połączenie
     */
    public void run(){
        try {
            socket = this.mmServerSocket.accept(10000);
            this.out = new PrintWriter(socket.getOutputStream(), true);
            this.in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.status = true;
        }
        catch (IOException e){
            this.status = false;
        }
        if(socket != null){
            try {
                mmServerSocket.close();
            }
            catch (Exception e){
            }
        }
    }

    /**
     * Wysłanie wiadomości
     *
     * @param wiadomosc wiadomość do wysłania
     *
     * @return Zawsze zwraca 0
     */
    public int wyslij(String wiadomosc){
        out.println(wiadomosc);
        return 0;
    }

    /**
     * Odebranie wiadomości
     *
     * @return Zwraca wiadomość lub treść błedu
     * jeśli wiadomość to "koniec" zamyka socket
     */
    public String odbierz(){
        try {
            String w = "Pusto";
            w = in.readLine();
            if (w == null) {
                w = "Blad";
            }
            else {
                if(w.equals("koniec")){
                    socket.close();
                }
            }
            return w;
        }
        catch (IOException e){
            return "Błąd połączenia";
        }
    }

    /**
     * Sprawdzenie stanu serwera
     * @return true - gotowy, false - nie gotowy
     */
    public boolean aktualnyStan(){
        return this.status;
    }
}
