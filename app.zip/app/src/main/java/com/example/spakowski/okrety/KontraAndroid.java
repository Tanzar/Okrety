package com.example.spakowski.okrety;

import android.content.DialogInterface;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.spakowski.okrety.Mechanizmy.Dodatkowe.RuchAndroida;
import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Statek;
import com.example.spakowski.okrety.Mechanizmy.Tryby.VsAndroid;

/**
 * Klasa aktywności gry przeciw androidowi
 */
public class KontraAndroid extends AppCompatActivity {
    //zmienne i obiekty do obsługi programu
    private VsAndroid gra;
    private boolean ustawioneStatki = false;    //zmienna zapamietuje czy statki zostaly ustawione
    private boolean ustawionyPoziom = false;    //zmienna sprawdza czy został ustawiony poziom trudności
    private boolean blokuj = false;
    private int x, y;                           //wymagane do ustawienia przycisków do strzału
    private int kier;
    private int kod;
    private Handler[] opoznienie;
    //obiekty z interfejsu
    private Button[] Poziomy;
    private TextView textPoziom;
    private TextView textTura;
    private ImageView[][] Mapa;
    private Button UstawStatki;
    private Button Graj;
    private ImageView[] PrzyciskiX;             //przyciski pod mapa, wybór współrzędnej X
    private ImageView[] PrzyciskiY;             //przyciski po boku mapy, wybór Y
    private Button Strzal;

    /**
     * Metoda przypisuje obrazki do tablicy mapy, dla layoutu przygotowania do gry
     * posiada okolo 100 linijek różniacych sie drobnymi szczegółami których nie można edytować za pomocą pętli
     */
    private void przypiszObrazkiUstaw(){
        /*
        Zakresy obiektów ImageView z layoutu na pola w tablicy
        (Wzór: numer rzędu( x = numer w tablicy, y - zakres numerów(10), ImageView(od liczby zlorzonej z X i Y +1 do liczby zlożonej z ostatniego Y i aktuelnego X zwiększonej o 1)
        Pierwszy rząd(y = 0, x <0, 9>, ImageView(1 - 10)
        Drugi rząd(y = 1, x <0, 9>, ImageView(11 - 20)
        itd.
         */
        //pierwszy rząd
        this.Mapa[0][0] = (ImageView) findViewById(R.id.imageView1);
        this.Mapa[0][1] = (ImageView) findViewById(R.id.imageView2);
        this.Mapa[0][2] = (ImageView) findViewById(R.id.imageView3);
        this.Mapa[0][3] = (ImageView) findViewById(R.id.imageView4);
        this.Mapa[0][4] = (ImageView) findViewById(R.id.imageView5);
        this.Mapa[0][5] = (ImageView) findViewById(R.id.imageView6);
        this.Mapa[0][6] = (ImageView) findViewById(R.id.imageView7);
        this.Mapa[0][7] = (ImageView) findViewById(R.id.imageView8);
        this.Mapa[0][8] = (ImageView) findViewById(R.id.imageView9);
        this.Mapa[0][9] = (ImageView) findViewById(R.id.imageView10);
        //drugi rząd
        this.Mapa[1][0] = (ImageView) findViewById(R.id.imageView11);
        this.Mapa[1][1] = (ImageView) findViewById(R.id.imageView12);
        this.Mapa[1][2] = (ImageView) findViewById(R.id.imageView13);
        this.Mapa[1][3] = (ImageView) findViewById(R.id.imageView14);
        this.Mapa[1][4] = (ImageView) findViewById(R.id.imageView15);
        this.Mapa[1][5] = (ImageView) findViewById(R.id.imageView16);
        this.Mapa[1][6] = (ImageView) findViewById(R.id.imageView17);
        this.Mapa[1][7] = (ImageView) findViewById(R.id.imageView18);
        this.Mapa[1][8] = (ImageView) findViewById(R.id.imageView19);
        this.Mapa[1][9] = (ImageView) findViewById(R.id.imageView20);
        //trzeci rząd
        this.Mapa[2][0] = (ImageView) findViewById(R.id.imageView21);
        this.Mapa[2][1] = (ImageView) findViewById(R.id.imageView22);
        this.Mapa[2][2] = (ImageView) findViewById(R.id.imageView23);
        this.Mapa[2][3] = (ImageView) findViewById(R.id.imageView24);
        this.Mapa[2][4] = (ImageView) findViewById(R.id.imageView25);
        this.Mapa[2][5] = (ImageView) findViewById(R.id.imageView26);
        this.Mapa[2][6] = (ImageView) findViewById(R.id.imageView27);
        this.Mapa[2][7] = (ImageView) findViewById(R.id.imageView28);
        this.Mapa[2][8] = (ImageView) findViewById(R.id.imageView29);
        this.Mapa[2][9] = (ImageView) findViewById(R.id.imageView30);
        //czwarty rząd
        this.Mapa[3][0] = (ImageView) findViewById(R.id.imageView31);
        this.Mapa[3][1] = (ImageView) findViewById(R.id.imageView32);
        this.Mapa[3][2] = (ImageView) findViewById(R.id.imageView33);
        this.Mapa[3][3] = (ImageView) findViewById(R.id.imageView34);
        this.Mapa[3][4] = (ImageView) findViewById(R.id.imageView35);
        this.Mapa[3][5] = (ImageView) findViewById(R.id.imageView36);
        this.Mapa[3][6] = (ImageView) findViewById(R.id.imageView37);
        this.Mapa[3][7] = (ImageView) findViewById(R.id.imageView38);
        this.Mapa[3][8] = (ImageView) findViewById(R.id.imageView39);
        this.Mapa[3][9] = (ImageView) findViewById(R.id.imageView40);
        //piąty rząd
        this.Mapa[4][0] = (ImageView) findViewById(R.id.imageView41);
        this.Mapa[4][1] = (ImageView) findViewById(R.id.imageView42);
        this.Mapa[4][2] = (ImageView) findViewById(R.id.imageView43);
        this.Mapa[4][3] = (ImageView) findViewById(R.id.imageView44);
        this.Mapa[4][4] = (ImageView) findViewById(R.id.imageView45);
        this.Mapa[4][5] = (ImageView) findViewById(R.id.imageView46);
        this.Mapa[4][6] = (ImageView) findViewById(R.id.imageView47);
        this.Mapa[4][7] = (ImageView) findViewById(R.id.imageView48);
        this.Mapa[4][8] = (ImageView) findViewById(R.id.imageView49);
        this.Mapa[4][9] = (ImageView) findViewById(R.id.imageView50);
        //szósty rząd
        this.Mapa[5][0] = (ImageView) findViewById(R.id.imageView51);
        this.Mapa[5][1] = (ImageView) findViewById(R.id.imageView52);
        this.Mapa[5][2] = (ImageView) findViewById(R.id.imageView53);
        this.Mapa[5][3] = (ImageView) findViewById(R.id.imageView54);
        this.Mapa[5][4] = (ImageView) findViewById(R.id.imageView55);
        this.Mapa[5][5] = (ImageView) findViewById(R.id.imageView56);
        this.Mapa[5][6] = (ImageView) findViewById(R.id.imageView57);
        this.Mapa[5][7] = (ImageView) findViewById(R.id.imageView58);
        this.Mapa[5][8] = (ImageView) findViewById(R.id.imageView59);
        this.Mapa[5][9] = (ImageView) findViewById(R.id.imageView60);
        //siódmy rząd
        this.Mapa[6][0] = (ImageView) findViewById(R.id.imageView61);
        this.Mapa[6][1] = (ImageView) findViewById(R.id.imageView62);
        this.Mapa[6][2] = (ImageView) findViewById(R.id.imageView63);
        this.Mapa[6][3] = (ImageView) findViewById(R.id.imageView64);
        this.Mapa[6][4] = (ImageView) findViewById(R.id.imageView65);
        this.Mapa[6][5] = (ImageView) findViewById(R.id.imageView66);
        this.Mapa[6][6] = (ImageView) findViewById(R.id.imageView67);
        this.Mapa[6][7] = (ImageView) findViewById(R.id.imageView68);
        this.Mapa[6][8] = (ImageView) findViewById(R.id.imageView69);
        this.Mapa[6][9] = (ImageView) findViewById(R.id.imageView70);
        //ósmy rząd
        this.Mapa[7][0] = (ImageView) findViewById(R.id.imageView71);
        this.Mapa[7][1] = (ImageView) findViewById(R.id.imageView72);
        this.Mapa[7][2] = (ImageView) findViewById(R.id.imageView73);
        this.Mapa[7][3] = (ImageView) findViewById(R.id.imageView74);
        this.Mapa[7][4] = (ImageView) findViewById(R.id.imageView75);
        this.Mapa[7][5] = (ImageView) findViewById(R.id.imageView76);
        this.Mapa[7][6] = (ImageView) findViewById(R.id.imageView77);
        this.Mapa[7][7] = (ImageView) findViewById(R.id.imageView78);
        this.Mapa[7][8] = (ImageView) findViewById(R.id.imageView79);
        this.Mapa[7][9] = (ImageView) findViewById(R.id.imageView80);
        //dziewiąty rząd
        this.Mapa[8][0] = (ImageView) findViewById(R.id.imageView81);
        this.Mapa[8][1] = (ImageView) findViewById(R.id.imageView82);
        this.Mapa[8][2] = (ImageView) findViewById(R.id.imageView83);
        this.Mapa[8][3] = (ImageView) findViewById(R.id.imageView84);
        this.Mapa[8][4] = (ImageView) findViewById(R.id.imageView85);
        this.Mapa[8][5] = (ImageView) findViewById(R.id.imageView86);
        this.Mapa[8][6] = (ImageView) findViewById(R.id.imageView87);
        this.Mapa[8][7] = (ImageView) findViewById(R.id.imageView88);
        this.Mapa[8][8] = (ImageView) findViewById(R.id.imageView89);
        this.Mapa[8][9] = (ImageView) findViewById(R.id.imageView90);
        //dziesiąty rząd
        this.Mapa[9][0] = (ImageView) findViewById(R.id.imageView91);
        this.Mapa[9][1] = (ImageView) findViewById(R.id.imageView92);
        this.Mapa[9][2] = (ImageView) findViewById(R.id.imageView93);
        this.Mapa[9][3] = (ImageView) findViewById(R.id.imageView94);
        this.Mapa[9][4] = (ImageView) findViewById(R.id.imageView95);
        this.Mapa[9][5] = (ImageView) findViewById(R.id.imageView96);
        this.Mapa[9][6] = (ImageView) findViewById(R.id.imageView97);
        this.Mapa[9][7] = (ImageView) findViewById(R.id.imageView98);
        this.Mapa[9][8] = (ImageView) findViewById(R.id.imageView99);
        this.Mapa[9][9] = (ImageView) findViewById(R.id.imageView100);
    }

    /**
     * Metoda czyści mapę, ustawienie obrazków na domyślny(woda.png)
     */
    private void resetMapyUstaw(){
        for(int i = 0; i < 10; i++){//petla czysci mape
            for(int j = 0; j < 10; j++){
                this.Mapa[i][j].setImageResource(R.drawable.woda);
            }
        }
    }

    /**
     * Metoda odświerza mapę, ustawienie obrazków na domyślne i umieszczenie statków na mapie
     */
    private void odswierzMapeUstaw(){
        Statek[] Statki = gra.getStatkiGracz();
        int[][] pozycje;

        resetMapyUstaw();

        for(int i = 0; i < 10; i++){//for przechodzi po każdym statku
            pozycje = Statki[i].getPozycje();
            for(int j = 0; j < Statki[i].getDlugosc(); j++) {//for przechodzi po wszystkich fragmentach statku
                Mapa[pozycje[j][1]][pozycje[j][0]].setImageResource(R.drawable.statek);
            }
        }
    }

    /**
     * Metod przypisuje obrazki dla layoutu android_gra do obiektów klasy
     */
    private void przypiszObrazkiGra(){
        /*
        Zakresy obiektów ImageView z layoutu na pola w tablicy
        (Wzór: numer rzędu( x = numer w tablicy, y - zakres numerów(10), ImageView(od liczby zlorzonej z X i Y +1 do liczby zlożonej z ostatniego Y i aktuelnego X zwiększonej o 1)
        Pierwszy rząd(y = 0, x <0, 9>, ImageView(1 - 10)
        Drugi rząd(y = 1, x <0, 9>, ImageView(11 - 20)
        itd.
         */
        //pierwszy rząd
        this.Mapa[0][0] = (ImageView) findViewById(R.id.imageView101);
        this.Mapa[0][1] = (ImageView) findViewById(R.id.imageView102);
        this.Mapa[0][2] = (ImageView) findViewById(R.id.imageView103);
        this.Mapa[0][3] = (ImageView) findViewById(R.id.imageView104);
        this.Mapa[0][4] = (ImageView) findViewById(R.id.imageView105);
        this.Mapa[0][5] = (ImageView) findViewById(R.id.imageView106);
        this.Mapa[0][6] = (ImageView) findViewById(R.id.imageView107);
        this.Mapa[0][7] = (ImageView) findViewById(R.id.imageView108);
        this.Mapa[0][8] = (ImageView) findViewById(R.id.imageView109);
        this.Mapa[0][9] = (ImageView) findViewById(R.id.imageView110);
        //drugi rząd
        this.Mapa[1][0] = (ImageView) findViewById(R.id.imageView111);
        this.Mapa[1][1] = (ImageView) findViewById(R.id.imageView112);
        this.Mapa[1][2] = (ImageView) findViewById(R.id.imageView113);
        this.Mapa[1][3] = (ImageView) findViewById(R.id.imageView114);
        this.Mapa[1][4] = (ImageView) findViewById(R.id.imageView115);
        this.Mapa[1][5] = (ImageView) findViewById(R.id.imageView116);
        this.Mapa[1][6] = (ImageView) findViewById(R.id.imageView117);
        this.Mapa[1][7] = (ImageView) findViewById(R.id.imageView118);
        this.Mapa[1][8] = (ImageView) findViewById(R.id.imageView119);
        this.Mapa[1][9] = (ImageView) findViewById(R.id.imageView120);
        //trzeci rząd
        this.Mapa[2][0] = (ImageView) findViewById(R.id.imageView121);
        this.Mapa[2][1] = (ImageView) findViewById(R.id.imageView122);
        this.Mapa[2][2] = (ImageView) findViewById(R.id.imageView123);
        this.Mapa[2][3] = (ImageView) findViewById(R.id.imageView124);
        this.Mapa[2][4] = (ImageView) findViewById(R.id.imageView125);
        this.Mapa[2][5] = (ImageView) findViewById(R.id.imageView126);
        this.Mapa[2][6] = (ImageView) findViewById(R.id.imageView127);
        this.Mapa[2][7] = (ImageView) findViewById(R.id.imageView128);
        this.Mapa[2][8] = (ImageView) findViewById(R.id.imageView129);
        this.Mapa[2][9] = (ImageView) findViewById(R.id.imageView130);
        //czwarty rząd
        this.Mapa[3][0] = (ImageView) findViewById(R.id.imageView131);
        this.Mapa[3][1] = (ImageView) findViewById(R.id.imageView132);
        this.Mapa[3][2] = (ImageView) findViewById(R.id.imageView133);
        this.Mapa[3][3] = (ImageView) findViewById(R.id.imageView134);
        this.Mapa[3][4] = (ImageView) findViewById(R.id.imageView135);
        this.Mapa[3][5] = (ImageView) findViewById(R.id.imageView136);
        this.Mapa[3][6] = (ImageView) findViewById(R.id.imageView137);
        this.Mapa[3][7] = (ImageView) findViewById(R.id.imageView138);
        this.Mapa[3][8] = (ImageView) findViewById(R.id.imageView139);
        this.Mapa[3][9] = (ImageView) findViewById(R.id.imageView140);
        //piąty rząd
        this.Mapa[4][0] = (ImageView) findViewById(R.id.imageView141);
        this.Mapa[4][1] = (ImageView) findViewById(R.id.imageView142);
        this.Mapa[4][2] = (ImageView) findViewById(R.id.imageView143);
        this.Mapa[4][3] = (ImageView) findViewById(R.id.imageView144);
        this.Mapa[4][4] = (ImageView) findViewById(R.id.imageView145);
        this.Mapa[4][5] = (ImageView) findViewById(R.id.imageView146);
        this.Mapa[4][6] = (ImageView) findViewById(R.id.imageView147);
        this.Mapa[4][7] = (ImageView) findViewById(R.id.imageView148);
        this.Mapa[4][8] = (ImageView) findViewById(R.id.imageView149);
        this.Mapa[4][9] = (ImageView) findViewById(R.id.imageView150);
        //szósty rząd
        this.Mapa[5][0] = (ImageView) findViewById(R.id.imageView151);
        this.Mapa[5][1] = (ImageView) findViewById(R.id.imageView152);
        this.Mapa[5][2] = (ImageView) findViewById(R.id.imageView153);
        this.Mapa[5][3] = (ImageView) findViewById(R.id.imageView154);
        this.Mapa[5][4] = (ImageView) findViewById(R.id.imageView155);
        this.Mapa[5][5] = (ImageView) findViewById(R.id.imageView156);
        this.Mapa[5][6] = (ImageView) findViewById(R.id.imageView157);
        this.Mapa[5][7] = (ImageView) findViewById(R.id.imageView158);
        this.Mapa[5][8] = (ImageView) findViewById(R.id.imageView159);
        this.Mapa[5][9] = (ImageView) findViewById(R.id.imageView160);
        //siódmy rząd
        this.Mapa[6][0] = (ImageView) findViewById(R.id.imageView161);
        this.Mapa[6][1] = (ImageView) findViewById(R.id.imageView162);
        this.Mapa[6][2] = (ImageView) findViewById(R.id.imageView163);
        this.Mapa[6][3] = (ImageView) findViewById(R.id.imageView164);
        this.Mapa[6][4] = (ImageView) findViewById(R.id.imageView165);
        this.Mapa[6][5] = (ImageView) findViewById(R.id.imageView166);
        this.Mapa[6][6] = (ImageView) findViewById(R.id.imageView167);
        this.Mapa[6][7] = (ImageView) findViewById(R.id.imageView168);
        this.Mapa[6][8] = (ImageView) findViewById(R.id.imageView169);
        this.Mapa[6][9] = (ImageView) findViewById(R.id.imageView170);
        //ósmy rząd
        this.Mapa[7][0] = (ImageView) findViewById(R.id.imageView171);
        this.Mapa[7][1] = (ImageView) findViewById(R.id.imageView172);
        this.Mapa[7][2] = (ImageView) findViewById(R.id.imageView173);
        this.Mapa[7][3] = (ImageView) findViewById(R.id.imageView174);
        this.Mapa[7][4] = (ImageView) findViewById(R.id.imageView175);
        this.Mapa[7][5] = (ImageView) findViewById(R.id.imageView176);
        this.Mapa[7][6] = (ImageView) findViewById(R.id.imageView177);
        this.Mapa[7][7] = (ImageView) findViewById(R.id.imageView178);
        this.Mapa[7][8] = (ImageView) findViewById(R.id.imageView179);
        this.Mapa[7][9] = (ImageView) findViewById(R.id.imageView180);
        //dziewiąty rząd
        this.Mapa[8][0] = (ImageView) findViewById(R.id.imageView181);
        this.Mapa[8][1] = (ImageView) findViewById(R.id.imageView182);
        this.Mapa[8][2] = (ImageView) findViewById(R.id.imageView183);
        this.Mapa[8][3] = (ImageView) findViewById(R.id.imageView184);
        this.Mapa[8][4] = (ImageView) findViewById(R.id.imageView185);
        this.Mapa[8][5] = (ImageView) findViewById(R.id.imageView186);
        this.Mapa[8][6] = (ImageView) findViewById(R.id.imageView187);
        this.Mapa[8][7] = (ImageView) findViewById(R.id.imageView188);
        this.Mapa[8][8] = (ImageView) findViewById(R.id.imageView189);
        this.Mapa[8][9] = (ImageView) findViewById(R.id.imageView190);
        //dziesiąty rząd
        this.Mapa[9][0] = (ImageView) findViewById(R.id.imageView191);
        this.Mapa[9][1] = (ImageView) findViewById(R.id.imageView192);
        this.Mapa[9][2] = (ImageView) findViewById(R.id.imageView193);
        this.Mapa[9][3] = (ImageView) findViewById(R.id.imageView194);
        this.Mapa[9][4] = (ImageView) findViewById(R.id.imageView195);
        this.Mapa[9][5] = (ImageView) findViewById(R.id.imageView196);
        this.Mapa[9][6] = (ImageView) findViewById(R.id.imageView197);
        this.Mapa[9][7] = (ImageView) findViewById(R.id.imageView198);
        this.Mapa[9][8] = (ImageView) findViewById(R.id.imageView199);
        this.Mapa[9][9] = (ImageView) findViewById(R.id.imageView200);

        PrzyciskiX = new ImageView[10];
        PrzyciskiY = new ImageView[10];
        //przypisanie do przycisków po boku
        PrzyciskiY[0] = (ImageView) findViewById(R.id.imageView201);
        PrzyciskiY[1] = (ImageView) findViewById(R.id.imageView202);
        PrzyciskiY[2] = (ImageView) findViewById(R.id.imageView203);
        PrzyciskiY[3] = (ImageView) findViewById(R.id.imageView204);
        PrzyciskiY[4] = (ImageView) findViewById(R.id.imageView205);
        PrzyciskiY[5] = (ImageView) findViewById(R.id.imageView206);
        PrzyciskiY[6] = (ImageView) findViewById(R.id.imageView207);
        PrzyciskiY[7] = (ImageView) findViewById(R.id.imageView208);
        PrzyciskiY[8] = (ImageView) findViewById(R.id.imageView209);
        PrzyciskiY[9] = (ImageView) findViewById(R.id.imageView210);
        //przyciski pod mapą
        PrzyciskiX[0] = (ImageView) findViewById(R.id.imageView211);
        PrzyciskiX[1] = (ImageView) findViewById(R.id.imageView212);
        PrzyciskiX[2] = (ImageView) findViewById(R.id.imageView213);
        PrzyciskiX[3] = (ImageView) findViewById(R.id.imageView214);
        PrzyciskiX[4] = (ImageView) findViewById(R.id.imageView215);
        PrzyciskiX[5] = (ImageView) findViewById(R.id.imageView216);
        PrzyciskiX[6] = (ImageView) findViewById(R.id.imageView217);
        PrzyciskiX[7] = (ImageView) findViewById(R.id.imageView218);
        PrzyciskiX[8] = (ImageView) findViewById(R.id.imageView219);
        PrzyciskiX[9] = (ImageView) findViewById(R.id.imageView220);
    }

    /**
     * Metoda ustawia obrazki dla PrzyciskiX(przyciski pod mapą) na domyślne
     */
    private void resetwyboruX(){
        PrzyciskiX[0].setImageResource(R.drawable.zero);
        PrzyciskiX[1].setImageResource(R.drawable.jeden);
        PrzyciskiX[2].setImageResource(R.drawable.dwa);
        PrzyciskiX[3].setImageResource(R.drawable.trzy);
        PrzyciskiX[4].setImageResource(R.drawable.cztery);
        PrzyciskiX[5].setImageResource(R.drawable.piec);
        PrzyciskiX[6].setImageResource(R.drawable.szesc);
        PrzyciskiX[7].setImageResource(R.drawable.siedem);
        PrzyciskiX[8].setImageResource(R.drawable.osiem);
        PrzyciskiX[9].setImageResource(R.drawable.dziewiec);
    }

    /**
     * Metoda ustawia obrazki dla PrzyciskiY(przyciski obok mapy) na domyślne
     */
    private void resetwyboruY(){
        PrzyciskiY[0].setImageResource(R.drawable.zero);
        PrzyciskiY[1].setImageResource(R.drawable.jeden);
        PrzyciskiY[2].setImageResource(R.drawable.dwa);
        PrzyciskiY[3].setImageResource(R.drawable.trzy);
        PrzyciskiY[4].setImageResource(R.drawable.cztery);
        PrzyciskiY[5].setImageResource(R.drawable.piec);
        PrzyciskiY[6].setImageResource(R.drawable.szesc);
        PrzyciskiY[7].setImageResource(R.drawable.siedem);
        PrzyciskiY[8].setImageResource(R.drawable.osiem);
        PrzyciskiY[9].setImageResource(R.drawable.dziewiec);
    }

    /**
     * Metoda zmienia obrazek na mapie,
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     * @param typ Określa jaki będzie obrazek:
     *            1 - woda
     *            2 - statek
     * @param wersja Określa rodzaj obrazka:
     *               1 - normalny
     *               2 - celuje
     *               3 - pudlo/zatopiony
     * @return Zwraca:
     * 0 - bez błedu
     * 1 - błąd, złe współrzędne
     * 2 - błąd, zły typ
     * 3 - błąd, zła wersja
     */
    private int zmienObrazek(int x, int y, int typ, int wersja){
        int kod = 0;
        if((x>9) || (x<0) || (y<0) || (y>9)){
            kod = 1;
        }
        else {
            switch (typ) {//wybór typu
                case 1://woda
                    switch(wersja){
                        case 1:
                            Mapa[y][x].setImageResource(R.drawable.woda);
                            break;
                        case 2:
                            Mapa[y][x].setImageResource(R.drawable.wodaceluje);
                            break;
                        case 3:
                            Mapa[y][x].setImageResource(R.drawable.wodapudlo);
                            break;
                        default:
                            kod = 3;
                            break;
                    }
                    break;
                case 2://statek pion
                    switch(wersja){
                        case 1:
                            Mapa[y][x].setImageResource(R.drawable.statek);
                            break;
                        case 2:
                            Mapa[y][x].setImageResource(R.drawable.statekceluje);
                            break;
                        case 3:
                            Mapa[y][x].setImageResource(R.drawable.statektrafiony);
                            break;
                        default:
                            kod = 3;
                            break;
                    }
                    break;
                default://jak zła wartość
                    kod = 2;
                    break;
            }
        }
        return kod;
    }

    /**
     * Metoda nanosi na mapę podaną Mapkę, bez nakładki
     *
     * @param Mapka tablica dwuwymiarowa Mapa pobierana z obiektu PrzezBluetooth, VsAndroid lub Plansza
     */
    private int rysujMapeGry(int[][] Mapka){
        int kod = 0;
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                kod = Mapka[j][i];
                switch(kod){
                    case 0:
                        this.Mapa[j][i].setImageResource(R.drawable.woda);
                        break;
                    case 1:
                        this.Mapa[j][i].setImageResource(R.drawable.wodapudlo);
                        break;
                    case 2:
                        this.Mapa[j][i].setImageResource(R.drawable.statektrafiony);
                        break;
                }
            }
        }
        return 0;
    }

    /**
     * Metoda nanosi na mapę podaną Mapkę z nakładką
     *
     * @param Mapka tablica dwuwymiarowa Mapa pobierana z obiektu PrzezBluetooth, VsAndroid lub Plansza
     * @param Nakladka tablica dwuwymiarowa Wzór pobierana z obiektu PrzezBluetooth, VsAndroid lub Plansza
     */
    private void rysujMapeGry(int[][] Mapka, boolean[][] Nakladka){
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                int kod = Mapka[i][j];
                switch (kod){
                    case 0:
                        if(Nakladka[i][j] == true){
                            this.Mapa[i][j].setImageResource(R.drawable.statek);
                        }
                        else {
                            this.Mapa[i][j].setImageResource(R.drawable.woda);
                        }
                        break;
                    case 1:
                        this.Mapa[i][j].setImageResource(R.drawable.wodapudlo);
                        break;
                    case 2:
                        this.Mapa[i][j].setImageResource(R.drawable.statektrafiony);
                        break;
                }
            }
        }
    }


    /**
     * Metoda wykonanuje tury androida razem z animacjami, do spudłowania
     */
    private int turadroid(){
        int ruchy = 0;
        int i = this.gra.getAktualnatura();
        RuchAndroida[] ruchyAndroida = this.gra.getTuryDroida();
        int dl;
        boolean koniec = false;
        dl = this.gra.getWygrana();

        while(koniec == false){     //petla zlicza ruchy do wykonania
            ruchy++;
            if(i <= dl) {//zabezpieczenie przed wyjściem poza zakres
                if(i == dl){
                    koniec = true;
                }
                else {
                    if (ruchyAndroida[i].getTrafiony() == false) {
                        koniec = true;
                    }
                }
            }
            i++;
        }

        for(i = 0; i < ruchy; i++){                 //wykonanie okreslonej liczby ruchów
            opoznienie[i].postDelayed(new Runnable() {
                @Override
                public void run() {
                    gra.wykonajTureDroid();
                    rysujMapeGry(gra.getMapaGracz(), gra.getWzorGracz());
                }
            }, i*1000);
        }
        opoznienie[20].postDelayed(new Runnable() {
            @Override
            public void run() {
                if(gra.koniecDroid() == true){
                    final AlertDialog Okienko = new AlertDialog.Builder(KontraAndroid.this).create();
                    Okienko.setTitle("Przegrana");
                    Okienko.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                            KontraAndroid.this.finish();
                        }
                    });
                    Okienko.show();
                }
                else {
                    rysujMapeGry(gra.getMapaDroid());
                    textTura.setText("Gracz");
                    blokuj = false;
                }
            }
        }, (i+1)*1000);
        return 0;
    }

    /**
     * Metoda nadpisuje nasłuchy dla wszystkich ImageView oraz przycisku strzału
     */
    private void ustawNasluchyGra(){
        //przyciski pod mapą
        //przycisk 0
        PrzyciskiX[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 0;
                    PrzyciskiX[0].setImageResource(R.drawable.zerowybrane);
                }
            }
        });
        //przycisk 1
        PrzyciskiX[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 1;
                    PrzyciskiX[1].setImageResource(R.drawable.jedenwybrane);
                }
            }
        });
        //przycisk 2
        PrzyciskiX[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 2;
                    PrzyciskiX[2].setImageResource(R.drawable.dwawybrane);
                }
            }
        });
        //przycisk 3
        PrzyciskiX[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 3;
                    PrzyciskiX[3].setImageResource(R.drawable.trzywybrane);
                }
            }
        });
        //przycisk 4
        PrzyciskiX[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 4;
                    PrzyciskiX[4].setImageResource(R.drawable.czterywybrane);
                }
            }
        });
        //przycisk 5
        PrzyciskiX[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 5;
                    PrzyciskiX[5].setImageResource(R.drawable.piecwybrane);
                }
            }
        });
        //przycisk 6
        PrzyciskiX[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 6;
                    PrzyciskiX[6].setImageResource(R.drawable.szescwybrane);
                }
            }
        });
        //przycisk 7
        PrzyciskiX[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 7;
                    PrzyciskiX[7].setImageResource(R.drawable.siedemwybrane);
                }
            }
        });
        //przycisk 8
        PrzyciskiX[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 8;
                    PrzyciskiX[8].setImageResource(R.drawable.osiemwybrane);
                }
            }
        });
        //przycisk 9
        PrzyciskiX[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruX();
                    x = 9;
                    PrzyciskiX[9].setImageResource(R.drawable.dziewiecwybrane);
                }
            }
        });

        //przyciski obok mapy
        //przycisk 0
        PrzyciskiY[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 0;
                    PrzyciskiY[0].setImageResource(R.drawable.zerowybrane);
                }
            }
        });
        //przycisk 1
        PrzyciskiY[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 1;
                    PrzyciskiY[1].setImageResource(R.drawable.jedenwybrane);
                }
            }
        });
        //przycisk 2
        PrzyciskiY[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 2;
                    PrzyciskiY[2].setImageResource(R.drawable.dwawybrane);
                }
            }
        });
        //przycisk 3
        PrzyciskiY[3].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 3;
                    PrzyciskiY[3].setImageResource(R.drawable.trzywybrane);
                }
            }
        });
        //przycisk 4
        PrzyciskiY[4].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 4;
                    PrzyciskiY[4].setImageResource(R.drawable.czterywybrane);
                }
            }
        });
        //przycisk 5
        PrzyciskiY[5].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 5;
                    PrzyciskiY[5].setImageResource(R.drawable.piecwybrane);
                }
            }
        });
        //przycisk 6
        PrzyciskiY[6].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 6;
                    PrzyciskiY[6].setImageResource(R.drawable.szescwybrane);
                }
            }
        });
        //przycisk 7
        PrzyciskiY[7].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 7;
                    PrzyciskiY[7].setImageResource(R.drawable.siedemwybrane);
                }
            }
        });
        //przycisk 8
        PrzyciskiY[8].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 8;
                    PrzyciskiY[8].setImageResource(R.drawable.osiemwybrane);
                }
            }
        });
        //przycisk 9
        PrzyciskiY[9].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    resetwyboruY();
                    y = 9;
                    PrzyciskiY[9].setImageResource(R.drawable.dziewiecwybrane);
                }
            }
        });

        //przycisk strzału
        Strzal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blokuj == false) {
                    blokuj = true;
                    kod = gra.strzalGracz(x, y);
                    if(kod != -1) {//jeśli jeszcze nie ostrzelane
                        Handler handle = new Handler();
                        if (kod == 1) {//pudło
                            zmienObrazek(x, y, 1, 2);
                            handle.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    zmienObrazek(x, y, 1, 3);

                                }
                            }, 1000);
                            handle.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    rysujMapeGry(gra.getMapaGracz(), gra.getWzorGracz());
                                    textTura.setText("Kapitan Droid");
                                }
                            }, 2000);
                            handle.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    turadroid();
                                }
                            }, 3000);

                        }
                        else {//trafienie
                            kier = gra.kierunekGracz(x, y);
                            zmienObrazek(x, y, 1, 2);
                            handle.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if(kod == 3){//zatopiony, zmiana wielu pól, odswierzenie calej mapy
                                        rysujMapeGry(gra.getMapaGracz(), gra.getWzorGracz());
                                    }
                                    else {//tylko trafiony, zmiana tylko 1 pola
                                        zmienObrazek(x, y, 2, 3);
                                    }
                                    if(gra.koniecGracz() == true){
                                        final AlertDialog Okienko = new AlertDialog.Builder(KontraAndroid.this).create();
                                        Okienko.setTitle("Wygrałeś!");
                                        Okienko.setButton(AlertDialog.BUTTON_NEUTRAL, "OK", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                dialog.dismiss();
                                                KontraAndroid.this.finish();
                                            }
                                        });
                                        Okienko.show();
                                    }
                                    else {
                                        blokuj = false;
                                        rysujMapeGry(gra.getMapaDroid());
                                    }
                                }
                            }, 1000);
                        }
                    }
                    else {
                        blokuj = false;
                    }

                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kontra_android);
        opoznienie = new Handler[21];     //20 dla możliwości rzadkiego przypadku ostrzelania wszystkich statkow w 1 turze(statki to łącznie 20 pól),handle o id=20 opóznia wyjście z tury droida
        for(int i = 0; i < 21; i++){
            opoznienie[i] = new Handler();
        }
        //tworzenie nowego obiektu do gry
        gra = new VsAndroid();
        //przypisanie przycisków wyboru poziomu i ich zachowań
        this.textPoziom = (TextView) findViewById(R.id.aktualnypoziom);
        this.Poziomy = new Button[3];
        this.Poziomy[0] = (Button) findViewById(R.id.latwybutton);
        this.Poziomy[1] = (Button) findViewById(R.id.srednibutton);
        this.Poziomy[2] = (Button) findViewById(R.id.trudnybutton);
        this.Poziomy[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gra.setPoziom(1);
                textPoziom.setText("Latwy");
                ustawionyPoziom = true;
            }
        });

        this.Poziomy[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gra.setPoziom(2);
                textPoziom.setText("Sredni");
                ustawionyPoziom = true;
            }
        });

        this.Poziomy[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gra.setPoziom(3);
                textPoziom.setText("Trudny");
                ustawionyPoziom = true;
            }
        });

        this.Mapa = new ImageView[10][10];
        this.przypiszObrazkiUstaw();//redukcja widocznego kodu dla jasności odczytu

        this.UstawStatki = (Button) findViewById(R.id.ustawstatki);
        this.UstawStatki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gra.wypelnijgracza();
                odswierzMapeUstaw();
                ustawioneStatki = true;
            }
        });

        this.Graj = (Button) findViewById(R.id.graj);
        this.Graj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if((ustawioneStatki == true) && (ustawionyPoziom == true)){
                    setContentView(R.layout.android_gra);
                    textTura = (TextView) findViewById(R.id.aktualnygracz);
                    Strzal = (Button) findViewById(R.id.strzal);
                    przypiszObrazkiGra();
                    gra.wypelnijTuryAndroida();     //wypełnienie tablic decyzji androida
                    ustawNasluchyGra();
                }
            }
        });
    }
}