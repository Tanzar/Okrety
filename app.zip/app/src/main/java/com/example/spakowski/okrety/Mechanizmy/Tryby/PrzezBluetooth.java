package com.example.spakowski.okrety.Mechanizmy.Tryby;

import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Plansza;

/**
 * Created by SPAKOWSKI on 2016-11-22.
 */

/**
 * Klasa gry przez Bluetooth
 * Zawiera planszę gracza i przeciwnika, pozwala wykonywać na nich operacje
 */
public class PrzezBluetooth {
    private Plansza Gracz;
    private Plansza Przeciwnik;

    /**
     * Konstruktor wypełnia losowo obie plansze
     */
    public PrzezBluetooth(){
        this.Gracz.wypelnij();
        this.Przeciwnik.wypelnij();
    }

    /**
     * Konstruktor tworzy obiekt na podstawie podanych plansz
     *
     * @param Przeciwnik plansza przeciwnika
     * @param Gracz plansza gracza
     */
    public PrzezBluetooth(Plansza Przeciwnik, Plansza Gracz) {
        this.Przeciwnik = Przeciwnik;
        this.Gracz = Gracz;
    }

    /**
     * Metoda wypełnia losow planszę przeciwnika
     */
    public void wypelnijPrzeciwnik(){
        this.Przeciwnik.wypelnij();
    }

    /**
     * Metoda wypełnia losowo planszę gracza
     */
    public void wypelnijGracz(){
        this.Gracz.wypelnij();
    }

    /**
     * Metoda zwraca mapę gracza
     * @return Zwraca mapę (int[10][10])
     */
    public int[][] getGraczMapa(){
        return this.Gracz.getMapa();
    }

    /**
     * Metoda zwraca wzór gracza
     * @return Zwraca wzór (boolean[10][10])
     */
    public boolean[][] getGraczWzor(){
        return this.Gracz.getWzor();
    }

    /**
     * Metoda zwraca wzór przeciwnika
     * @return Zwraca wzór (boolean[10][10])
     */
    public boolean[][] getPrzeciwnikWzor(){
        return this.Przeciwnik.getWzor();
    }

    /**
     * Metoda zwraca mapę przeciwnika
     * @return Zwraca mapę (int[10][10])
     */
    public int[][] getPrzeciwnikMapa(){
        return this.Przeciwnik.getMapa();
    }

    /**
     * Metoda wykonuje strzał na mapę gracza(ruch przeciwnika)
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     *
     * @return Zwraca:
     *  1 - gdy nie trafiło
     *  2 - jeżeli trafiło, ale nie zatopiło
     *  3 - jeżeli trafiło i zatopiło
     *  -1 - juz ostrzelane lub błędne współrzędne
     */
    public int strzalPrzeciwnik(int x, int y){
        int kod = this.Gracz.strzal(x, y);
        return kod;
    }

    /**
     * Metoda wykonuje strzał na mapę przeciwnika(ruch gracza)
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     *
     * @return Zwraca:
     *  1 - gdy nie trafiło
     *  2 - jeżeli trafiło, ale nie zatopiło
     *  3 - jeżeli trafiło i zatopiło
     *  -1 - juz ostrzelane lub błędne współrzędne
     */
    public int strzalGracz(int x, int y){
        int kod;
        if((x < 10) && (x > -1) && (y > -1) && (y < 10)){
            kod = this.Przeciwnik.strzal(x, y);
        }
        else {
            kod = -1;
        }
        return kod;
    }

    /**
     * Metoda sprawdza czy nastapił koniec gry u Przeciwnika
     *
     * @return true - tak, false - nie
     */
    public boolean koniecPrzeciwnik(){
        int zatopione = Gracz.getZatopione();
        if(zatopione == 10){
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Metoda sprawdza czy nastapił koniec gry u Gracza
     *
     * @return true - tak, false - nie
     */
    public boolean koniecGracz(){
        int zatopione = Przeciwnik.getZatopione();
        if(zatopione == 10){
            return true;
        }
        else {
            return false;
        }
    }
}
