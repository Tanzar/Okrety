package com.example.spakowski.okrety;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;

/**
 * Główna klasa applikacji
 */
public class MainActivity extends AppCompatActivity {
    private Button androidbutton;       //przycisk trybu gry przeciw "androidowi"
    private Button bluetoothbutton;     //przycisk trybu gry z wykorzystaniem bluetooth
    private Button informacje;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //przypisanie zmiennych typu button do istniejących w layoucie przycisków (activity_main.xml)
        this.androidbutton = (Button) findViewById(R.id.androidbutton);
        this.bluetoothbutton = (Button) findViewById(R.id.bluetoothbutton);
        this.informacje = (Button) findViewById(R.id.informacje);

        /*
        ustawienie Listenera dla przycisku gry przeciw androidowi
        stworzenie intencji(intent) i wykorzystanie jej do otwarcia nowej aktywności(okna gry)
         */
        this.androidbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = getApplicationContext();
                Intent intent = new Intent(context, KontraAndroid.class);

                startActivity(intent);
            }
        });
        /*
        ustawienie Listenera dla przycisku gry przez bluetooth
        otwarcie okna ustawień bluetooth
         */
        this.bluetoothbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = getApplicationContext();
                Intent intent = new Intent(context, GraBluetooth.class);
                startActivity(intent);

            }
        });

        this.informacje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = getApplicationContext();
                Intent intent = new Intent(context, Informacje.class);
                startActivity(intent);
            }
        });
    }
}
