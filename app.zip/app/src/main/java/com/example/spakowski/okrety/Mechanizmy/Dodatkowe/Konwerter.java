package com.example.spakowski.okrety.Mechanizmy.Dodatkowe;

import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Statek;

/**
 * Created by SPAKOWSKI on 2016-11-29.
 */

/**
 * Klasa wykorzystywana do konwersji Statków na paczki i paczek na statki
 */
public class Konwerter {
    private int charToInt(char c){
        int l;
        switch (c){
            case '0':
                l = 0;
                break;
            case '1':
                l = 1;
                break;
            case '2':
                l = 2;
                break;
            case '3':
                l = 3;
                break;
            case '4':
                l = 4;
                break;
            case '5':
                l = 5;
                break;
            case '6':
                l = 6;
                break;
            case '7':
                l = 7;
                break;
            case '8':
                l = 8;
                break;
            case '9':
                l = 9;
                break;
            default:
                l = -1;
                break;
        }
        return l;
    }

    /**
     * Zamienia statki na "paczki" czyli ciągi cyfr przedstawiające kolejno - dlugość, kierunek i pozycje(x1, y1, x2, y2..)
     *
     * @param statki tablica 10 statków
     *
     * @return Zwraca tablicę 10 ciągów znaków, każdy reprezentuje jeden statek
     */
    public String[] StatkiNaPaczki(Statek[] statki){
        String[] paczki = new String[10];
        for(int i = 0; i < 10; i++){
            String paczka;
            paczka = String.valueOf(statki[i].getDlugosc());
            paczka = paczka + String.valueOf(statki[i].getKierunek());
            for(int j = 0; j < statki[i].getDlugosc(); j++){
                paczka = paczka + String.valueOf(statki[i].getPozycje()[j][0]) + String.valueOf(statki[i].getPozycje()[j][1]);
            }
            paczki[i] = paczka;
        }
        return paczki;
    }
    /**
     * Zamienia paczki(tablicę 10 Stringów) na statki
     *
     * @param paczki tablica 10 ciągów znaków, każdy reprezentuje 1 statek
     *
     * @return Zwraca tablice 10 statków
     */
    public Statek[] PaczkiNaStatki(String[] paczki){
        Statek[] statki = new Statek[10];
        for(int i = 0; i < 10; i++){
            String p = paczki[i];
            statki[i] = new Statek();
            char[] c = p.toCharArray();
            statki[i].setDlugosc(charToInt(c[0]));
            statki[i].setKierunek(charToInt(c[1]));
            int[][] poz = new  int[4][2];
            int k = 2;
            for(int j = 0; j < statki[i].getDlugosc(); j++){
                poz[j][0] = charToInt(c[k]);
                poz[j][1] = charToInt(c[k+1]);
                k = k +2;
            }
            statki[i].setPozycje(poz);
        }
        return statki;
    }
}
