package com.example.spakowski.okrety.Mechanizmy.Polaczenie;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import com.example.spakowski.okrety.KontraAndroid;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.UUID;

/**
 * Created by SPAKOWSKI on 2016-11-22.
 */

/**
 * Klasa klienta odpowiedzialna za połączenie z serwerem i komunikację
 */
public class KlientBluetooth extends Thread {
    private final BluetoothSocket mmSocket;
    private final BluetoothDevice mmDevice;
    private BufferedReader in;
    private PrintWriter out;
    private boolean status = false;

    /**
     * Konstruktor tworzy obiekt odpowiedzialny za połączenie
     *
     * @param device urządzenie od którego będą wykonywane próby połączenia
     */
    public KlientBluetooth(BluetoothDevice device){
        BluetoothSocket tmp = null;
        this.mmDevice = device;
        try {
            UUID uuid = UUID.fromString("b791d4c7-c29d-4cb9-aa3a-233ae216e593");
            tmp = device.createInsecureRfcommSocketToServiceRecord(uuid);
        }
        catch (Exception e){
        }
        this.mmSocket = tmp;
    }

    /**
     * Metoda wykonuje próbę połączenia, tworzy socket do komunikacji
     */
    public void run(){
        try {
            BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();
            ba.cancelDiscovery();
            this.mmSocket.connect();
            this.in = new BufferedReader(new InputStreamReader(this.mmSocket.getInputStream()));
            this.out = new PrintWriter(this.mmSocket.getOutputStream(), true);
            this.status = true;
        }
        catch (Exception ce){
            try {
                this.mmSocket.close();
            }
            catch (Exception cle){
            }
        }
    }

    /**
     * Metoda wysyła podaną wiadomość
     *
     * @param wiadomosc Wiadomość do wysłania
     *
     * @return Zawsze Zwraca 0
     */
    public int wyslij(String wiadomosc){
        out.println(wiadomosc);
        return 0;
    }

    /**
     * Metoda odbiera wiadomość
     *
     * @return Zwraca wiadomość,
     * jeśli nastąpił błąd zwróci intormację
     */
    public String odbierz(){
        try {
            String w = "Pusto";
            w = in.readLine();
            if (w == null) {
                w = "Blad";
            }
            return w;
        }
        catch (IOException e){
            return "Błąd połączenia";
        }
    }

    /**
     * Metoda sprawdza aktualny stan klienta
     *
     * @return true - klient gotowy, false - klient nie gotowy
     */
    public boolean aktualnyStan(){
        return this.status;
    }
}
