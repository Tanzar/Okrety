package com.example.spakowski.okrety.Mechanizmy.Podstawowe;

/**
 * Created by SPAKOWSKI on 2016-10-29.
 */

/**
 * Podstawowa klasa reprezentuje statek, zawiera pozycje, kierunek i długość statku
 */
public class Statek {
    private int kierunek;       //ustawienie statku na planszy, 1 - góra, 2 - dół, 3 - prawo, 4 - lewo
    private int[][] Pozycje;    //pozycje każego fragmentu statku, drugie id(Pozycje[][id]) 0 to X, 1 to Y
    private int dlugosc;        //dlugosc statku, ile pól zajmuje

    /**
     * Podstawowy Konstruktor
     */
    public Statek(){
        this.Pozycje = new int[4][2];
    }

    /**
     * Konstruktor inicjujący wartości na domyslne
     * kierunek na 1
     * dlugosc na podaną wartość jeśli poza zakresem <1, 4> wtedy ustawia domyslnie 4
     * pozycje na 20
     */
    public Statek(int dlugosc){
        this.kierunek = 1;
        if((dlugosc>0) && (dlugosc<5)) {
            this.dlugosc = dlugosc;
        }
        else{
            this.dlugosc = 4;
        }
        this.Pozycje = new int[4][2];
        for(int i = 0; i < 4; i++){
            this.Pozycje[i][0] = 20;
            this.Pozycje[i][1] = 20;
        }
    }

    /**
     * Konstruktor tworzy statek o podanych parametrach
     *
     * @param dlugosc dlugość statku (1..4)
     * @param kierunek kierunek statku(1..4)
     * @param pozycje tablica pozycji(int[4][2], int[][0] oznacza współrzędną X, int[][1] współrzędna Y)
     */
    public Statek(int dlugosc, int kierunek, int[][]pozycje){
        this.dlugosc = dlugosc;
        this.kierunek = kierunek;
        this.Pozycje = pozycje;
    }

    /**
     * Ustawienie tablicy z pozycjami fragmentów statku,
     *
     * @param Poz tablica pozycji(int[4][2], int[][0] oznacza współrzędną X, int[][1] współrzędna Y)
     *
     * @return Zwraca 0 jak nie było błędu,
     * 1 jak podana wartość to null,
     * 2 jak długość tablicy nie jest równa 4
    */
    public int setPozycje(int[][] Poz){
        if(Poz == null){
            return 1;       //podana tablica nie istnieje
        }
        else{
            if(Poz.length == 4){
                this.Pozycje = Poz;
                return 0;       //brak błędu
            }
            else{
                return 2;   //podana tablica ma złą długość
            }
        }
    }

    public void setKierunek(int kier){
        this.kierunek = kier;
    }

    public int getKierunek(){
        return this.kierunek;
    }

    public int[][] getPozycje(){
        return this.Pozycje;
    }

    public int getDlugosc(){
        return this.dlugosc;
    }

    /**
     * @return Zwraca 1 jesli wartość poza zakresem <1, 4> lub 0 jesli nie było błędu
     */
    public int setDlugosc(int dl){
        if((dl>0) && (dl<5)) {
            this.dlugosc = dl;
            return 0;
        }
        else{
            return 1;
        }
    }

    /**
     * Metoda ustawia pozycje na donyślne
     */
    public void ustawDomyslne(){
        for(int i = 0; i < 4; i++){
            this.Pozycje[i][0] = 20;
            this.Pozycje[i][1] = 20;
        }
    }
}
