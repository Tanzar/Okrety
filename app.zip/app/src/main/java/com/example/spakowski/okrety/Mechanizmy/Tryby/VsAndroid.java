package com.example.spakowski.okrety.Mechanizmy.Tryby;

import com.example.spakowski.okrety.Mechanizmy.Dodatkowe.Pozycja;
import com.example.spakowski.okrety.Mechanizmy.Dodatkowe.RuchAndroida;
import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Plansza;
import com.example.spakowski.okrety.Mechanizmy.Podstawowe.Statek;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by SPAKOWSKI on 2016-10-30.
 */

/**
 * Klasa gry Przeciw Androidowi, zawiera plansze gracza i androida oraz mechanizmy przygowowujące grę w tym trybie
 */
public class VsAndroid {
    private Plansza Gracz;
    private Plansza Droid;
    private int poziom = 0;
    private RuchAndroida[] turyDroida;
    private int aktualnatura = 0;
    private int wygrana;                    //id ruchu w którym android wygrywa
    private ArrayList<Pozycja> mozliwePozycje;
    private boolean faza = false;         //flaga zapamiętuje która faza ostrzału jest aktywna
    private int idtrafienia;                    //dla poziomu normalnego - id ostatniego trafienia, dla poziomu trudnego - id fragmentu trafionego statku
    private int idpierwszego;                      //poziom normalny - id pierwszego trafionego fragmentu, poziom trudny - id trafionego statku
    private int kier = 1;


    /**
     * Konstruktor, wypełnia planszę androida i tworzy pustą planszę gracza
     */
    public VsAndroid(){
        this.turyDroida = new RuchAndroida[100];    //maxymalnie bedzie 100 ruchów(plansza ma 100 pól)
        mozliwePozycje = new ArrayList<Pozycja>();
        Droid = new Plansza();
        Droid.wypelnij();

        Gracz = new Plansza();
    }

    /**
     * Ustawienie poziomu trudności jeśli poda się niewłąściwy metoda nic nie zrobi
     * @param p poziom(1..3)
     *          1 - poziom łatwy, android zawsze ostrzeliwuje losowe pola
     *          2 - posiom normalny, android ostrzeliwuje losowe pola do trafienia, potem strzela schematem, poisany przy metodzie decyzjaNormalny()
     *          3 poziom trudny, losowe ostrzeliwanie to trafienia, gdy trafi nie myli sie przy kolejnych strzałach(zawsze strzela w trafiony statek do zatopienia)
     */
    public void setPoziom(int p){
        if((p < 4) || (p > 0)){
            this.poziom = p;
        }
    }

    /**
     * Zwraca wzór gracza
     * @return wzór (boolean[10][10], true - statek, false - woda)
     */
    public boolean[][] getWzorGracz(){
        return this.Gracz.getWzor();
    }

    /**
     * Zwraca mapę Gracza
     * @return mapa (int[10][10], 0-nieostrzelane, 1-pudło, 2-trafienie)
     */
    public int[][] getMapaGracz(){
        return this.Gracz.getMapa();
    }

    /**
     * Zwraca mapę androida
     * @return mapa (int[10][10], 0-nieostrzelane, 1-pudło, 2-trafienie)
     */
    public int[][] getMapaDroid(){
        return this.Droid.getMapa();
    }

    /**
     * zwraca tablicę statków gracza
     * @return zwraca tablicę dziesięciu statków gracza
     */
    public Statek[] getStatkiGracz(){
        return this.Gracz.getStatki();
    }

    /**
     * Metoda zwraca aktualną ture androida
     * @return zwraca numer tury(strzału) androida
     */
    public int getAktualnatura(){
        return this.aktualnatura;
    }

    /**
     * Metoda zwraca numer tury w której android wygrywa
     * @return id tury
     */
    public int getWygrana(){
        return this.wygrana;
    }

    /**
     * Metoda sprawdza czy gracz wygrał
     *
     * @return true - gracz wygrał, false - jeszcze nie ma końca
     */
    public boolean koniecGracz(){
        int zatopione;
        zatopione = Droid.getZatopione();
        if(zatopione == 10){
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Metoda sprawdza czy android wygrał
     *
     * @return true - android wygrał, false - jeszcze nie ma końca
     */
    public boolean koniecDroid(){
        int zatopione;
        zatopione = Gracz.getZatopione();
        if(zatopione == 10){
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Zwraca tablicę ruchów androida(do 100)
     * @return tablica zwracana ma różną długość(max 100 elementów)
     */
    public RuchAndroida[] getTuryDroida(){
        return this.turyDroida;
    }

    /**
     * Metoda wypełnia listę możliwych decyzji(wszystkie pola)
     *
     * @return Zawsze zwraca 0
     */
    private int wypelnijListe(){
        this.mozliwePozycje.clear();//czyszczenie cokolwiek zostało na starej liście
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                Pozycja poz = new Pozycja(i, j);
                this.mozliwePozycje.add(poz);
            }
        }
        return 0;
    }

    /**
     * Metoda, wypełnia losowo planszę gracza
     *
     * @return Zawsze zwraca 0
     */
    public int wypelnijgracza(){
        Gracz.wypelnij();
        return 0;
    }

    /**
     * Metoda wykonuje strzał gracza
     *
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     *
     * @return Zwraca:
     * 1 - pudło
     * 2 - trafienie bez zatopienia
     * 3 - trafienie z zatopieniem
     * -1 - juz to pole ostrzelano, błędne współrzędne
     */
    public int strzalGracz(int x, int y){
        int kod = 0;
        if((x < 10) && (x > -1) && (y > -1) && (y < 10)){
            kod = Droid.strzal(x, y);
        }
        else {
            kod = -1;
        }
        return kod;
    }

    /**
     * Metoda sprawdza kierunek statku na podanych koordynatach
     *
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     *
     * @return Zwraca:
     * kierunek statku na podanych koordynatach
     * 0 - gdy nie ma statku lub sa bledne koordynaty
     */
    public int kierunekGracz(int x, int y){
        Statek[] statki = Gracz.getStatki();
        int kier = 0;
        for(int i = 0; i < 10; i++){//po statkach
            int[][] poz = statki[i].getPozycje();
            int dl = statki[i].getDlugosc();
            for(int j = 0; j < dl; j++){//po pozycjach
                if(poz[j][0]==x && poz[j][1]==y){
                    kier = statki[i].getKierunek();
                    j = dl;
                    i = 10;
                }
            }
        }
        return kier;
    }

    /**
     * Metoda ustawia wybrany statek na polu w określonym kierunku
     *
     * @param id id ustawianego statku (0..9)
     * @param x współrzędna X (0..9)
     * @param y współrzędna Y (0..9)
     * @param kier kierunek statku (1..4)
     *
     * @return Zwraca:
     * 0 - nie wystąpił błąd
     * 1 - błędne id, musi byc zakres <0, 9>
     * 2 - błędne wartości X lub Y, musi być <0, 9>
     * 3 - błedny kierunek, musi być z zakresu <1, 4>
     * 4 - kolizja, układ statku koliduje se scianą
     * 5 - kolizja, pozycje statku kolidują z innym statkiem
     */
    public int ustaw(int id, int x, int y, int kier){
        int blad = 0;
        blad = Gracz.umiesc(id, x, y, kier);
        return blad;
    }

    /**
     * Metoda podejmująca decyzję dla poziomu łatwego
     * strzały zawsze losowe
     *
     * @return Zwraca obiekt typu RuchAndroida reprezentuje jedną decyzję
     */
    private RuchAndroida decyzjaLatwy(){
        RuchAndroida aktualny = new RuchAndroida();
        Random rand = new Random();
        int id = rand.nextInt(this.mozliwePozycje.size());//wyjęcie z listy losowej pozycji
        Pozycja poz = this.mozliwePozycje.get(id);
        int xa = poz.getX();
        int ya = poz.getY();
        this.mozliwePozycje.remove(id);
        int kod = -1;
        while(kod == -1) {
            kod = Gracz.strzal(xa, ya);
            switch (kod){
                case 1:
                    aktualny = new RuchAndroida(xa, ya, false);
                    break;
                case 2:
                    aktualny = new RuchAndroida(xa, ya, true);
                    break;
                case 3:
                    aktualny = new RuchAndroida(xa, ya, true);
                    break;
                case -1:
                    id = rand.nextInt(this.mozliwePozycje.size());
                    poz = this.mozliwePozycje.get(id);
                    xa = poz.getX();
                    ya = poz.getY();
                    this.mozliwePozycje.remove(id);
                    break;
            }
        }
        return aktualny;
    }

    /**
     * Metoda podejmująca decyzje dla poziomu normalnego
     * Ostrzeliwuje pola losowo do trafienia,
     * Gdy trafi strzela w pola obok,
     * gdy trafi po raz kolejny strzela w wybranym kierunku,
     * jeśli spudłuje lub dotrze do końca mapy zawraca do punktu startu i ostrzeliwuje z przeciwnym kierunku
     * gdy zatopi wraca do losowego otrzeliwania pól
     *
     * @param idruchu id aktualnego ruchu
     *
     * @return Zwraca obiekt typu RuchAndroida reprezentuje jedną decyzję
     */
    private RuchAndroida decyzjaNormalny(int idruchu){
        RuchAndroida aktualny = new RuchAndroida();
        int kod = -1;
        if(faza == false){    //brak trafień, wykonujemy przypadkowe strzały
            Random rand = new Random();
            int id = rand.nextInt(this.mozliwePozycje.size());//wyjęcie z listy losowej pozycji
            Pozycja poz = this.mozliwePozycje.get(id);
            int xa = poz.getX();
            int ya = poz.getY();
            this.mozliwePozycje.remove(id);
            while(kod == -1) {
                kod = Gracz.strzal(xa, ya);
                switch (kod){
                    case 1://pudło
                        aktualny = new RuchAndroida(xa, ya, false, kod);
                        this.faza = false;
                        break;
                    case 2:     //faza statku dłuższego niz 1
                        aktualny = new RuchAndroida(xa, ya, true, kod);
                        this.faza = true;
                        this.idtrafienia = idruchu;
                        this.idpierwszego = idruchu;
                        break;
                    case 3:     //zatopiono statek o długości 1
                        aktualny = new RuchAndroida(xa, ya, true, kod);
                        break;
                    case -1://powtórzenie strzału
                        id = rand.nextInt(this.mozliwePozycje.size());
                        poz = this.mozliwePozycje.get(id);
                        xa = poz.getX();
                        ya = poz.getY();
                        this.mozliwePozycje.remove(id);
                        break;
                }
            }
        }
        else {  //jeśli już nastąpiły jakieś trafienia
            int xo = this.turyDroida[this.idtrafienia].getX();  //x ostatniego trafienia
            int yo = this.turyDroida[this.idtrafienia].getY();  //y ostatniego trafienia
            int xn = xo;
            int yn = yo;
            boolean flaga = false;
            while (kod == -1){
                xo = this.turyDroida[this.idtrafienia].getX();  //x ostatniego trafienia
                yo = this.turyDroida[this.idtrafienia].getY();  //y ostatniego trafienia
                xn = xo;
                yn = yo;
                switch (kier){
                    case 1:
                        yn = yo - 1;
                        break;
                    case 2:
                        xn = xo + 1;
                        break;
                    case 3:
                        yn = yo + 1;
                        break;
                    case 4:
                        xn = xo - 1;
                        break;
                    case 5:
                        int k = 1;
                        k = 0;
                        break;
                }
                if(xn > 9 || xn < 0 || yn > 9 || yn < 0){
                    kod = -1;
                    flaga = true;
                }
                else{
                    kod = Gracz.strzal(xn, yn);
                    flaga = false;
                }
                switch (kod){
                    case 1:
                        aktualny = new RuchAndroida(xn, yn, false, kod);
                        if(this.idtrafienia != this.idpierwszego){
                            switch (this.kier){
                                case 1:
                                    kier = 3;
                                    break;
                                case 2:
                                    kier = 4;
                                    break;
                                case 3:
                                    kier = 1;
                                    break;
                                case 4:
                                    kier = 2;
                                    break;
                            }
                        }
                        else {
                            kier++;
                        }
                        break;
                    case 2:
                        aktualny = new RuchAndroida(xn, yn, true, kod);
                        this.idtrafienia = idruchu;
                        break;
                    case 3:
                        aktualny = new RuchAndroida(xn, yn, true, kod);
                        this.faza = false;
                        kier = 1;
                        break;
                    case -1:
                        if(flaga == true){
                            if(this.idpierwszego != this.idtrafienia){
                                switch (this.kier){
                                    case 1:
                                        kier = 3;
                                        break;
                                    case 2:
                                        kier = 4;
                                        break;
                                    case 3:
                                        kier = 1;
                                        break;
                                    case 4:
                                        kier = 2;
                                        break;
                                }
                            }
                            else {
                                kier++;
                            }
                        }
                        else {
                            if(Gracz.jestStatek(xn, yn) == false){
                                kier++;
                            }
                            else {
                                this.idtrafienia = this.idpierwszego;
                            }
                        }
                        break;
                }
            }
        }
        return aktualny;
    }

    /**
     * Metoda podejmująca decyzję dla poziomu trudnego
     * Wykonywanie losowych strzałów do trafienia.
     * Gdy trafi wykorzystuje tablice statków by ustalić kolejne decyzje.
     * Ostrzeliwuje statek do zatopienia.
     *
     * @return Zwraca obiekt typu RuchAndroida reprezentuje jedną decyzję
     */
    private RuchAndroida decyzjaTrudny(){
        RuchAndroida aktualny = new RuchAndroida();
        int kod = -1;
        if(faza == false){    //brak trafień, wykonujemy przypadkowe strzały
            Random rand = new Random();
            int id = rand.nextInt(this.mozliwePozycje.size());//wyjęcie z listy losowej pozycji
            Pozycja poz = this.mozliwePozycje.get(id);
            int xa = poz.getX();
            int ya = poz.getY();
            this.mozliwePozycje.remove(id);
            while(kod == -1) {
                kod = Gracz.strzal(xa, ya);
                switch (kod){
                    case 1://pudło
                        aktualny = new RuchAndroida(xa, ya, false, kod);
                        this.faza = false;
                        break;
                    case 2:     //faza statku dłuższego niz 1
                        aktualny = new RuchAndroida(xa, ya, true, kod);
                        this.idpierwszego = Gracz.podajIdStatku(xa, ya);
                        this.idtrafienia = 0;
                        this.faza = true;
                        break;
                    case 3:     //zatopiono statek o długości 1
                        aktualny = new RuchAndroida(xa, ya, true, kod);
                        break;
                    case -1://powtórzenie strzału
                        id = rand.nextInt(this.mozliwePozycje.size());
                        poz = this.mozliwePozycje.get(id);
                        xa = poz.getX();
                        ya = poz.getY();
                        this.mozliwePozycje.remove(id);
                        break;
                }
            }
        }
        else {  //jeśli już nastąpiły jakieś trafienia
            while (kod == -1){
                int xa = Gracz.getStatki()[this.idpierwszego].getPozycje()[this.idtrafienia][0];    //współrzędna x trafionego statku
                int ya = Gracz.getStatki()[this.idpierwszego].getPozycje()[this.idtrafienia][1];    //współrzędna y trafionego statku
                kod = Gracz.strzal(xa, ya);
                switch (kod){
                    case 2:
                        aktualny = new RuchAndroida(xa, ya, true, kod);
                        this.idtrafienia++;
                        break;
                    case 3:
                        aktualny = new RuchAndroida(xa, ya, true, kod);
                        this.faza = false;
                        break;
                    case -1:
                        this.idtrafienia++;
                        break;
                }
            }
        }
        return aktualny;
    }

    /**
     * Metoda wypełnia tablicę tur androida
     *
     * @return Zawsze zwraca 0
     */
    public int wypelnijTuryAndroida() {
        wypelnijListe();
        this.Gracz.resetMapy();
        boolean koniec = false;
        int i = 0;                  //iterator po numerach decyzji w tablicy
        while (koniec == false){
            switch (this.poziom){
                case 1:
                    turyDroida[i] = decyzjaLatwy();
                    break;
                case 2:
                    turyDroida[i] = decyzjaNormalny(i);
                    break;
                case 3:
                    turyDroida[i] = decyzjaTrudny();
                    break;
            }
            if(this.Gracz.getZatopione() == 10){
                this.wygrana = i;
                koniec = true;
            }
            else {
                i++;
            }
        }
        this.Gracz.resetMapy();
        return 0;
    }

    /**
     * Metoda wykonuje aktualną turę adroida
     *
     * @return zwraca kod strzału:
     * 1 - pudło
     * 2 - trafienie bez zatopienia
     * 3 - trafienie z zatopieniem
     * -1 - pole już ostrzelano
     */
    public int wykonajTureDroid(){
        int x = turyDroida[this.aktualnatura].getX();
        int y = turyDroida[this.aktualnatura].getY();
        int kod;
        kod = this.Gracz.strzal(x, y);
        this.aktualnatura++;
        return kod;
    }
}
