package com.example.spakowski.okrety.Mechanizmy.Podstawowe;

import java.util.Random;

/**
 * Created by SPAKOWSKI on 2016-10-29.
 */

/**
 * Klasa przechowująca informacje na temat Planszy gracza
 */
public class Plansza {
    private boolean[][] Wzor;   //tablica reprezentująca układ statków na planszy, true oznacza statek, false puste pole, pierwsza tablica to Y druga to X
    private int[][] Mapa;       //tablica zapisująca "ostrzelane" pola, 0 - nieostrzelane, 1 - nietrafione, 2 - trafiony
    private Statek[] Statki;    //tablica statkow na planszy
    private boolean Ustawione = false;
    private int zatopione;

    /**
     * Domyślny konstruktor, tworzy domyślną mapę, wzór i tablicę statków
     */
    public Plansza(){
        this.zatopione = 0;
        this.Wzor = new boolean[10][10];

        //wypelnianie wzoru wartosciami domyslnymi, false
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                this.Wzor[i][j] = false;
            }
        }

        this.Mapa = new int[10][10];
        //wypelnianie mapy wartosciami domyslnymi, 0
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                this.Mapa[i][j] = 0;
            }
        }

        //wypenienie tablicy statków, w kolejności 4 masztowiec, 3 masztowce, 2 masztowce i 1 masztowce
        this.Statki = new Statek[10];
        for(int i = 0; i < 10; i++){
            if(i==0){                               //pierwszy statek
                this.Statki[i] = new Statek(4);
            }
            else{
                if(i<3){                            //statki o numerze w tabeli 1 oraz 2
                    this.Statki[i] = new Statek(3);
                }
                else{
                    if(i<6){                        //statki o numerach 3, 4, 5
                        this.Statki[i] = new Statek(2);
                    }
                    else{                           //pozostałe statki (6, 7, 8, 9)
                        this.Statki[i] = new Statek(1);
                    }
                }
            }
        }
    }

    /**
     * Konstruktor tworzy planszę bazując na tablicy statków
     * tablica musi mieć indexy 0..9 inaczej pozostałe funkcje będą działać niepoprawnie
     * Kolejność statków jest bez znaczenia, musi ich byc 10 inaczej wystapi wyjątek Indexu poza zakresem
     *
     * @param statki tablica 10 statków(musi zawierać statki o długościach(4, 3, 3, 2, 2, 2, 1, 1, 1, 1)
     */
    public Plansza(Statek[] statki){
        this.Statki = statki;

        this.Mapa = new int[10][10];
        //wypelnianie mapy wartosciami domyslnymi, 0
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                this.Mapa[i][j] = 0;
            }
        }
        this.zatopione = 0;
        this.Wzor = new boolean[10][10];
        //wypelnianie wzoru wartosciami domyslnymi, false
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                this.Wzor[i][j] = false;
            }
        }

        for(int i = 0; i < 10; i++){
            int dl = statki[i].getDlugosc();
            int[][] poz = statki[i].getPozycje();
            for(int j = 0; j < dl; j++){
                int x = poz[j][0];
                int y = poz[j][1];
                this.Wzor[y][x] = true;
            }
        }
    }

    /**
     * @return  Zwraca Wzór, tablica Boolean[10][10] gdzie true oznacza pozycję statku
     */
    public boolean[][] getWzor(){
        return this.Wzor;
    }

    /**
     * @return Zwraca mapę, tablica Int[10][10] gdzie występują wartości 0-pole nie ostrzelane, 1-pudło, 2-trafienie
     */
    public int[][] getMapa(){
        return this.Mapa;
    }

    /**
     * @return Zwraca Tablicę dziesięciu statków
     */
    public Statek[] getStatki(){
        return this.Statki;
    }

    /**
     * @return Zwraca ilość zatopionych statków
     */
    public int getZatopione(){
        return this.zatopione;
    }

    /**
     * Metoda sprawdza czy na podanych koordynatach znajduje się statek czy woda
     *
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     *
     * @return true - statek, false - woda
     */
    public boolean jestStatek(int x, int y){
        return this.Wzor[y][x];
    }

    /**
     * Metoda sprawdza czy na podanych koordynatach(z zakresu 0..9 na obu) znajduje sie statek
     *
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     *
     * @return Zwraca id statku, jeśli nie ma statku zwraca -1, jeśli podano złe wartości zwraca -2
     */
    public int podajIdStatku(int x, int y){
        int xt;     //współrzedne po pierwszym sprawdzeniu
        int yt;
        int[][] poz;    //zmienna przechowuje tabele pozycji sprawdzanego statku, ustawiony domyślnie na 1 gdyż kompilator informował o braku inicjalizacji
        int dlugosc;
        int id = -1;
        if((x<10) && (x>-1) && (y<10) && (y>-1)) {
            for (int i = 0; i < 10; i++) {             //sprawdzenie który statek trafiliśmy
                poz = this.Statki[i].getPozycje();
                dlugosc = this.Statki[i].getDlugosc();
                for (int j = 0; j < dlugosc; j++) {
                    xt = poz[j][0];
                    yt = poz[j][1];
                    if ((xt == x) && (yt == y)) {
                        id = i;
                        j = dlugosc;
                        i = 10;
                    }
                }
            }
        }
        else {
            id = -2;
        }
        return id;
    }

    /**
     *  Metoda sprawdza czy statek na podanych koordynatach został zatopiony
     *
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     *
     * @return Zwraca
     *  id statku który został zatopiony,
     *  -1 jesli tylko trafiony
     */
    private int zatopiony(int x, int y){
        int xt;     //współrzedne po pierwszym sprawdzeniu
        int yt;
        int[][] poz = this.Statki[0].getPozycje();    //zmienna przechowuje tabele pozycji sprawdzanego statku, ustawiony domyślnie na 1 gdyż kompilator informował o braku inicjalizacji
        int dlugosc = 0;
        int id = 0;
        for(int i = 0; i < 10; i++){             //sprawdzenie który statek trafiliśmy
            poz = this.Statki[i].getPozycje();
            dlugosc = this.Statki[i].getDlugosc();
            for(int j = 0; j < dlugosc; j++){
                xt = poz[j][0];
                yt = poz[j][1];
                if((xt == x) && (yt == y)){
                    id = i;
                    j = dlugosc;
                    i = 10;
                }
            }
        }

        //w tym momencie mamy id statku który został trafiony
        for(int i = 0; i < dlugosc; i++){
            xt = poz[i][0];
            yt = poz[i][1];
            if(Mapa[yt][xt] == 0) {
                i = dlugosc;
                id = -1;
            }
        }
        if(id != -1){
            this.zatopione++;
        }
        return id;
    }

    /**
     *  Metoda oznacza pola wokół statku na nietrafione
     *
     *  @param id id oznaczanego statku(0..9)
     *
     *  @return Zawsze zwraca 0
     */
    private int oznaczPola(int id){
        int xp = 0, yp = 0, xk = 0, yk = 0;
        int kier = this.Statki[id].getKierunek();
        int x = this.Statki[id].getPozycje()[0][0];
        int y = this.Statki[id].getPozycje()[0][1];
        int dlugosc = this.Statki[id].getDlugosc();
        //wyliczanie xp, xk, yp, yk
        /*
        pozycje x, y to punkty poczatkowe statku
        xp to pozycja poczatkowa x
        xk to pozycja koncowa x
        pozycje te sa odpowiednio po lewej(xp), prawej(xk), powyzej(yp), ponizej(yk) od x i y
        wyliczane są zależnie od kierunku statku(dl - dlugość statku)

        kierunek    xp      xk      yp      yk
        1           x-1     x+1     y-dl    y+1
        2           x-1     x+1     y-1     y+dl
        3           x-1     x+dl    y-1     y+1
        4           x-dl    x+1     y-1     y+1
         */
        switch(kier){
            case 1:
                xp = x-1;
                xk = x+1;
                yp = y-dlugosc;
                yk = y+1;
                break;
            case 2:
                xp = x-1;
                xk = x+1;
                yp = y-1;
                yk = y+dlugosc;
                break;
            case 3:
                xp = x-1;
                xk = x+dlugosc;
                yp = y-1;
                yk = y+1;
                break;
            case 4:
                xp = x-dlugosc;
                xk = x+1;
                yp = y-1;
                yk = y+1;
                break;
        }

        //nowym zadaniem zmiennej kier jest wybór kierunku oznaczania
        kier = 1;
        x = xp;
        y = yp;
        int iloscpol = 2*dlugosc+6;
        for(int i = 0; i < iloscpol; i++){
            switch(kier){
                case 1:
                    if(!((x > 9) || (x < 0) || (y > 9) || (y < 0))){
                        this.Mapa[y][x]=1;
                    }
                    x++;
                    if(x > xk){//zmiana kierunku oznaczania
                        kier = 2;
                        x = xk;
                        y++;
                    }
                    break;
                case 2:
                    if(!((x > 9) || (x < 0) || (y > 9) || (y < 0))){
                        this.Mapa[y][x]=1;
                    }
                    y++;
                    if(y > yk){//zmiana kierunku oznaczania
                        kier = 3;
                        y = yk;
                        x--;
                    }
                    break;
                case 3:
                    if(!((x > 9) || (x < 0) || (y > 9) || (y < 0))){
                        this.Mapa[y][x]=1;
                    }
                    x--;
                    if(x < xp){//zmiana kierunku oznaczania
                        kier = 4;
                        x = xp;
                        y--;
                    }
                    break;
                case 4:
                    if(!((x > 9) || (x < 0) || (y > 9) || (y < 0))){
                        this.Mapa[y][x]=1;
                    }
                    y--;
                    if(y < yp){//zmiana kierunku oznaczania
                        kier = 1;
                        y = yp;
                    }
                    break;
            }
        }
        return 0;
    }

    /**
     *  Metoda zmieniająca wartości na tablicy Mapa bazując na Wzorze i podanych współrzędnych z zakresu 0..9
     *
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     *
     *  @return Zwraca:
     *  1 - gdy nie trafiło
     *  2 - jeżeli trafiło, ale nie zatopiło
     *  3 - jeżeli trafiło i zatopiło
     *  -1 - juz ostrzelane lub błędne współrzędne
     */
    public int strzal(int x, int y){
        int id;
        int kod = 0;
        if((x<10) && (x>-1) && (y<10) && (y>-1)) {
            if (Mapa[y][x] == 0) {
                if (Wzor[y][x] == true) {
                    this.Mapa[y][x] = 2;
                    id = zatopiony(x, y);
                    if (id > -1) {
                        oznaczPola(id);
                        kod = 3;
                    } else {
                        kod = 2;
                    }
                } else {
                    this.Mapa[y][x] = 1;
                    kod = 1;
                }
            } else {
                kod = -1;
            }
        }
        else {
            kod = -1;
        }
        return kod;
    }

    /**
     * Metoda testująca pozycje w zależności do pozostałych statków i scianek
     *
     * @param id id sprawdzanego statku(0..9)
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     * @param kier kierunek statku(1..4)
     *
     * @return Zwraca:
     * 0 - nie następuje kolizja
     * 1 - kolizja ze scianą
     * 2 - kolicja z innym statkiem
     */
    private int testPozycji(int id, int x, int y, int kier){
        int xp = -1, xk = -1, yp = -1, yk = -1;
        int kod = 0;
        //wyliczanie xp, xk, yp, yk
        /*
        pozycje x, y to punkty poczatkowe statku
        xp to pozycja poczatkowa x
        xk to pozycja koncowa x
        pozycje te sa odpowiednio po lewej(xp), prawej(xk), powyzej(yp), ponizej(yk) od x i y
        wyliczane są zależnie od kierunku statku(dl - dlugość statku)

        kierunek    xp      xk      yp      yk
        1           x-1     x+1     y-dl    y+1
        2           x-1     x+1     y-1     y+dl
        3           x-1     x+dl    y-1     y+1
        4           x-dl    x+1     y-1     y+1
         */
        switch(kier){
            case 1:
                xp = x-1;
                xk = x+1;
                yp = y-this.Statki[id].getDlugosc();
                yk = y+1;
                break;
            case 2:
                xp = x-1;
                xk = x+1;
                yp = y-1;
                yk = y+this.Statki[id].getDlugosc();
                break;
            case 3:
                xp = x-1;
                xk = x+this.Statki[id].getDlugosc();
                yp = y-1;
                yk = y+1;
                break;
            case 4:
                xp = x-this.Statki[id].getDlugosc();
                xk = x+1;
                yp = y-1;
                yk = y+1;
                break;
        }

        //sprawdzenie czy jakakolwiek wartość przekracza scianki
        if((xp > 10) || (xp < -1)){
            kod = 1;
        }
        if((xk > 10) || (xk < -1)){
            kod = 1;
        }
        if((yp > 10) || (yp < -1)){
            kod = 1;
        }
        if((yk > 10) || (yk < -1)){
            kod = 1;
        }
        if (kod == 0) {
            //petla sprawdzająca kolizję z innymi statkami pozostały statek
            for (int i = 0; i < 10; i++) {
                if (i != id) {
                    int[][] pozycje = this.Statki[i].getPozycje();
                    //pętla sprawdzająca każdy punkt danego statku
                    int dlugosc = this.Statki[i].getDlugosc();
                    for (int j = 0; j < dlugosc; j++) {
                        int xs, ys;
                        xs = pozycje[j][0];
                        ys = pozycje[j][1];
                        if (((xs <= xk) && (xs >= xp)) && ((ys >= yp) && (ys <= yk))) {
                            kod = 2;
                            i = 10;
                            j = 5;
                        }
                    }
                }
            }
        }
        return kod;
    }

    /**
     * Metoda ustawia statek o podanym id(0..9) na koordynatach x, y w kierunki kier(1..4)
     * x, y muszą być z zakresu 0..9
     *
     * @param id id dodawanego statku(0..9)
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     * @param kier kierunek dodawanego statku(1..4)
     *
     * @return Zawsze zwraca 0
     */
    private int dodaj(int id, int x, int y, int kier){
        if((id<10) && (id>-1) && (x<10) && (x>-1) && (y<10) && (y>-1) && (kier>0) && (kier<5)) {
            int[][] Pozycje = this.Statki[id].getPozycje();
            int dlugosc = this.Statki[id].getDlugosc();
            //"podmiana" statku
            this.Statki[id].setKierunek(kier);
            switch (kier) {
                case 1:
                    for (int i = 0; i < dlugosc; i++) {
                        Pozycje[i][0] = x;
                        Pozycje[i][1] = y - i;
                    }
                    break;
                case 2:
                    for (int i = 0; i < dlugosc; i++) {
                        Pozycje[i][0] = x;
                        Pozycje[i][1] = y + i;
                    }
                    break;
                case 3:
                    for (int i = 0; i < dlugosc; i++) {
                        Pozycje[i][0] = x + i;
                        Pozycje[i][1] = y;
                    }
                    break;
                case 4:
                    for (int i = 0; i < dlugosc; i++) {
                        Pozycje[i][0] = x - i;
                        Pozycje[i][1] = y;
                    }
                    break;
            }

            this.Statki[id].setPozycje(Pozycje);

            //wstawienie statku na wzor
            for (int i = 0; i < dlugosc; i++) {
                int xs = Pozycje[i][0];
                int ys = Pozycje[i][1];
                this.Wzor[ys][xs] = true;
            }
        }
        return 0;
    }

    /**
     * Metoda umieszcza statek o podanym id na koordynatach x, y w kierunku kier
     *
     * @param id id dodawanego statku(0..9)
     * @param x współrzędna x(0..9)
     * @param y współrzędna y(0..9)
     * @param kier kierunek dodawanego statku(1..4)
     *
     * @return Zwraca kody błędu:
     * 0 - nie wystąpił błąd
     * 1 - błędne id, musi byc zakres <0, 9>
     * 2 - błędne wartości X lub Y, musi być <0, 9>
     * 3 - błedny kierunek, musi być z zakresu <1, 4>
     * 4 - kolizja, układ statku koliduje se scianą
     * 5 - kolizja, pozycje statku kolidują z innym statkiem
     */
    public int umiesc(int id, int x, int y, int kier){
        int kod = 0;
        //sprawdzenie wartości id
        if((id > 9) || (id < 0)){
            kod = 1;
        }
        else{
            //sprawdzenie wartości x, y
            if(((x>9) || (x<0)) || ((y>9) || (y<0))){
                kod = 2;
            }
            else {
                if((kier < 1) && (kier > 4)){
                    kod = 3;
                }
                else {
                    int blad; //zmienna błędu
                    //sprawdzanie mapy czy nie następuje jakakolwiek kolizja
                    blad = testPozycji(id, x, y, kier);
                    switch(blad){
                        case 0:
                            dodaj(id, x, y, kier);
                            kod = 0;
                            break;
                        case 1:
                            kod = 4;   //kolizja ze scianą
                            break;
                        case 2:
                            kod = 5;   //kolizja z innym statkiem
                            break;
                    }
                }
            }
        }
        return kod;
    }

    /**
     * Metoda usuwająca statek z wzoru(restatruje jego zmienne, odstawia do puli statków)
     *
     * @param id id usuwanego statku(0..9)
     *
     * @return Zwraca:
     * 0 - gdy nie nastąpił błąd
     * 1 - błędna wartość id, musi byc z zakresu <0, 9>
     */
    public int usunstatek(int id){
        if((id < 0) || (id > 9)){
            return 1;
        }
        else{
            Statek usuwany = this.Statki[id];
            //usuniecie statku ze Wzoru
            for(int i = 0; i < usuwany.getDlugosc(); i++) {
                int x = usuwany.getPozycje()[i][0];
                int y = usuwany.getPozycje()[i][1];
                this.Wzor[y][x] = false;
            }
            //ustawienie w statku wartości na domyslne
            usuwany.ustawDomyslne();
            this.Statki[id]=usuwany;
            return 0;
        }
    }

    /**
     * Metoda restartuje mapę, zeruje
     *
     * @return Zawsze zwraca 0
     */
    public int resetMapy(){
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                this.Mapa[i][j] = 0;
            }
        }
        this.zatopione = 0;
        return 0;
    }

    /**
     * Metoda usuwa statki z planszy
     *
     * @return Zawsze zwraca 0
     */
    public int resetStatkow(){
        if(Ustawione == true) {
            for (int i = 0; i < 10; i++) {
                this.usunstatek(i);
            }
        }
        this.zatopione = 0;
        return 0;
    }

    /**
     * Metoda wypełnia planszę losowo ustawionymi statkami
     *
     * @return Zawsze zwraca 0
     */
    public int wypelnij(){
        boolean koniec = false;
        Random rand = new Random();
        int id = 0;
        this.resetStatkow();
        while(koniec == false){
            //przygotowanie pseudolosowych wartości dla statku
            int randx = rand.nextInt(10);
            int randy = rand.nextInt(10);
            int randkier = rand.nextInt(5);
            while(randkier==0){
                randkier = rand.nextInt(5);
            }
            int blad = 0;

            blad = umiesc(id, randx, randy, randkier);

            if(blad == 0){
                id = id + 1;
            }
            if(id > 9){
                koniec = true;
            }
        }
        this.Ustawione = true;
        return 0;
    }

}
