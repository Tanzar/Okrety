package com.example.spakowski.okrety.Mechanizmy.Dodatkowe;

/**
 * Created by SPAKOWSKI on 2016-11-19.
 */

/**
 * Klasa zapisująca pozycję X i Y
 */
public class Pozycja {
    private int x;
    private int y;

    public Pozycja(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX(){
        return this.x;
    }

    public int getY(){
        return this.y;
    }

    public void setX(int x){
        this.x = x;
    }

    public void setY(int y){
        this.y = y;
    }
}
